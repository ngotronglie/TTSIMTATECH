<!DOCTYPE html>
<html lang="en-US">
 <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!-- Basic Page Info -->
<meta http-equiv="x-ua-compatible" content="ie=edge" />
<link rel="profile" href="https://gmpg.org/xfn/11" />
<meta name="theme-color" content="#5a00f0" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="viewport" content="width=device-width, initial-scale=1" />

<!-- Favicon -->
			<link rel="icon" href="https://solverwp.com/wp-content/themes/mayosis/images/fav.png" type="image/x-icon">
		<title>Page not found &#8211; Solver Wp</title>
<meta name='robots' content='max-image-preview:large' />
<!-- Jetpack Site Verification Tags -->
<meta name="google-site-verification" content="TLCf8rRkMICWxkHx1z19o8CN7NzvGW3BAYy9BaFvNBA" />
<link rel='dns-prefetch' href='//c0.wp.com' />
<link href='https://fonts.gstatic.com' crossorigin rel='preconnect' />
<link rel="alternate" type="application/rss+xml" title="Solver Wp &raquo; Feed" href="https://solverwp.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Solver Wp &raquo; Comments Feed" href="https://solverwp.com/comments/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/solverwp.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.4.5"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83e\udef1\ud83c\udffb\u200d\ud83e\udef2\ud83c\udfff","\ud83e\udef1\ud83c\udffb\u200b\ud83e\udef2\ud83c\udfff")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://c0.wp.com/c/6.4.5/wp-includes/css/dist/block-library/style.min.css' type='text/css' media='all' />
<style id='wp-block-library-inline-css' type='text/css'>
.has-text-align-justify{text-align:justify;}
</style>
<style id='wp-block-library-theme-inline-css' type='text/css'>
.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:hsla(0,0%,100%,.65)}.wp-block-audio{margin:0 0 1em}.wp-block-code{border:1px solid #ccc;border-radius:4px;font-family:Menlo,Consolas,monaco,monospace;padding:.8em 1em}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:hsla(0,0%,100%,.65)}.wp-block-embed{margin:0 0 1em}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:hsla(0,0%,100%,.65)}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:hsla(0,0%,100%,.65)}.wp-block-image{margin:0 0 1em}.wp-block-pullquote{border-bottom:4px solid;border-top:4px solid;color:currentColor;margin-bottom:1.75em}.wp-block-pullquote cite,.wp-block-pullquote footer,.wp-block-pullquote__citation{color:currentColor;font-size:.8125em;font-style:normal;text-transform:uppercase}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;font-style:normal;position:relative}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large,.wp-block-quote.is-style-plain{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-search__button{border:1px solid #ccc;padding:.375em .625em}:where(.wp-block-group.has-background){padding:1.25em 2.375em}.wp-block-separator.has-css-opacity{opacity:.4}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto}.wp-block-separator.has-alpha-channel-opacity{opacity:1}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table{margin:0 0 1em}.wp-block-table td,.wp-block-table th{word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video{margin:0 0 1em}.wp-block-template-part.has-background{margin-bottom:0;margin-top:0;padding:1.25em 2.375em}
</style>
<link rel='stylesheet' id='mediaelement-css' href='https://c0.wp.com/c/6.4.5/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css' href='https://c0.wp.com/c/6.4.5/wp-includes/js/mediaelement/wp-mediaelement.min.css' type='text/css' media='all' />
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--color--light-gray: #f5f5f5;--wp--preset--color--medium-gray: #999;--wp--preset--color--dark-gray: #222a36;--wp--preset--color--purple: #5a00f0;--wp--preset--color--dark-blue: #28375a;--wp--preset--color--red: #c44d58;--wp--preset--color--yellow: #ecca2e;--wp--preset--color--green: #64a500;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 14px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 26px;--wp--preset--font-size--x-large: 42px;--wp--preset--font-size--normal: 16px;--wp--preset--font-size--huge: 36px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://solverwp.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.4' type='text/css' media='all' />
<link rel='stylesheet' id='edd-styles-css' href='https://solverwp.com/wp-content/plugins/easy-digital-downloads/templates/edd.min.css?ver=2.11.5' type='text/css' media='all' />
<link rel='stylesheet' id='em-puchase-code-validator-css' href='https://solverwp.com/wp-content/plugins/em-purchase-code-validator/public/assets/css/em-puchase-code-validator-public.css?ver=1.1' type='text/css' media='all' />
<link rel='stylesheet' id='before-after-css-css' href='https://solverwp.com/wp-content/plugins/mayosis-core/public/elementor/assets/css/mayo-elementor.css?ver=1.1' type='text/css' media='all' />
<link rel='stylesheet' id='mayosis-core-css' href='https://solverwp.com/wp-content/plugins/mayosis-core/public/css/mayosis-core-public.css?ver=3.6.8' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css' href='https://c0.wp.com/c/6.4.5/wp-includes/css/dashicons.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='edd-reviews-css' href='https://solverwp.com/wp-content/plugins/edd-reviews/assets/css/edd-reviews.min.css?ver=2.1.11' type='text/css' media='all' />
<link rel='stylesheet' id='mayosis-style-css' href='https://solverwp.com/wp-content/themes/mayosis/style.css?ver=6.4.5' type='text/css' media='all' />
<link rel='stylesheet' id='mayosis-bootstrap-css' href='https://solverwp.com/wp-content/themes/mayosis/css/bootstrap.min.css?ver=6.4.5' type='text/css' media='all' />
<link rel='stylesheet' id='mayosis-essential-css' href='https://solverwp.com/wp-content/themes/mayosis/css/essential.css?ver=6.4.5' type='text/css' media='all' />
<link rel='stylesheet' id='plyr-css' href='https://solverwp.com/wp-content/themes/mayosis/css/plyr.css?ver=6.4.5' type='text/css' media='all' />
<link rel='stylesheet' id='swiperjs-css' href='https://solverwp.com/wp-content/themes/mayosis/css/swiper.min.css?ver=6.4.5' type='text/css' media='all' />
<link rel='stylesheet' id='mayosis-main-style-css' href='https://solverwp.com/wp-content/themes/mayosis/css/main.min.css?ver=6.4.5' type='text/css' media='all' />
<link rel='stylesheet' id='zeroicon-line-css' href='https://solverwp.com/wp-content/themes/mayosis/css/zero-icon-line.css?ver=6.4.5' type='text/css' media='all' />
<link rel='stylesheet' id='beerslidercss-css' href='https://solverwp.com/wp-content/themes/mayosis/css/BeerSlider.css?ver=6.4.5' type='text/css' media='all' />
<link rel='stylesheet' id='edd-user-profiles-css' href='https://solverwp.com/wp-content/plugins/mayosis-core/library/user-profile//assets/css/edd-user-profiles.min.css?ver=6.4.5' type='text/css' media='all' />
<link rel='stylesheet' id='jetpack_css-css' href='https://c0.wp.com/p/jetpack/10.9.2/css/jetpack.css' type='text/css' media='all' />
<script type="text/javascript" src="https://c0.wp.com/c/6.4.5/wp-includes/js/jquery/jquery.min.js" id="jquery-core-js"></script>
<script type="text/javascript" src="https://c0.wp.com/c/6.4.5/wp-includes/js/jquery/jquery-migrate.min.js" id="jquery-migrate-js"></script>
<script type="text/javascript" id="mayosis-edd-ajax-search-script-js-extra">
/* <![CDATA[ */
var mayosis_edd_search_wp_ajax = {"ajaxurl":"https:\/\/solverwp.com\/wp-admin\/admin-ajax.php","ajaxnonce":"2febe8cbee"};
/* ]]> */
</script>
<script type="text/javascript" src="https://solverwp.com/wp-content/plugins/mayosis-core/library/extensions/mayosis-live-search/js/mayosis-ajax-search.js?ver=1.0.1" id="mayosis-edd-ajax-search-script-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/plugins/em-purchase-code-validator/public/assets/js/vue.min.js?ver=1.1" id="em-vue-lib-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/plugins/em-purchase-code-validator/public/assets/js/moment.js?ver=1.1" id="em-vue-moment-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/plugins/em-purchase-code-validator/public/assets/js/moment-timezone.min.js?ver=1.1" id="em-vue-moment-tz-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/plugins/em-purchase-code-validator/public/assets/js/axios.min.js?ver=1.1" id="em-axios-lib-js"></script>
<script type="text/javascript" id="teconce-follow-js-extra">
/* <![CDATA[ */
var teconce_vars = {"processing_error":"There was a problem processing your request.","login_required":"Oops, you must be logged-in to follow users.","logged_in":"false","ajaxurl":"https:\/\/solverwp.com\/wp-admin\/admin-ajax.php","nonce":"88526f4a78"};
/* ]]> */
</script>
<script type="text/javascript" src="https://solverwp.com/wp-content/plugins/mayosis-core/library/user-follow/js/follow.js?ver=6.4.5" id="teconce-follow-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/plugins/mayosis-core/public/js/mayosis-core-public.js?ver=3.6.8" id="mayosis-core-js"></script>
<!--[if lt IE 9]>
<script type="text/javascript" src="https://solverwp.com/wp-content/themes/mayosis/js/html5.js?ver=3.7.3" id="html5-js"></script>
<![endif]-->
<script type="text/javascript" id="edd-user-profiles-js-extra">
/* <![CDATA[ */
var edd_user_profiles = {"queried_user":"","spinner":"<div class=\"edd-user-profiles-spinner\"><\/div>"};
/* ]]> */
</script>
<script type="text/javascript" src="https://solverwp.com/wp-content/plugins/mayosis-core/library/user-profile//assets/js/edd-user-profiles.min.js?ver=1" id="edd-user-profiles-js"></script>
<link rel="https://api.w.org/" href="https://solverwp.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://solverwp.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.4.5" />
<meta name="generator" content="Easy Digital Downloads v2.11.5" />

	<style type="text/css">
		a.paddle_button.pay-popup{
			border: 1px solid #5a00f0;
		    background: #5a00f0;
		    color: #fff;
		    padding: 13px;
		    border-radius: 5px;
		    text-align: center;
		    width: 210px;
		}
		.product_widget_inside a.paddle_button.pay-popup{
			margin-bottom: 10px;
			width: 270px;
		}

	</style>
	<style type='text/css'>img#wpstats{display:none}</style>
	        <script type="text/javascript">
            var ajaxurl = 'https://solverwp.com/wp-admin/admin-ajax.php';
        </script>
        <style id="mayosis-custom-css" type="text/css">.tag_widget_single ul li a, .sidebar-blog-categories ul li, .title--box--btn.transparent {border-color:rgba(40,55,90,0.25) !important;}::selection {background:#28375a;}::-moz-selection {background:#28375a;}.mayosel-select .option:hover,.mayosel-select .option.focus {background-color:rgba(40,55,90,0.25);} .plyr--audio .plyr__control.plyr__tab-focus, .plyr--audio .plyr__control:hover, .plyr--audio .plyr__control[aria-expanded=true] {background:#5a00f0;}.plyr--audio .plyr__control.plyr__tab-focus {box-shadow:0 0 0 16pxrgba(90,0,240,0.25);}input[type="range"]::-moz-range-track,input[type="range"]::-moz-range-progress,input[type="range"]::-webkit-slider-runnable-track {background-color:rgba(40,55,90,0.65);}input[type="range"]::-webkit-slider-runnable-track,input[type="range"]:focus::-webkit-slider-runnable-track {background-color:rgba(40,55,90,0.65);}input[type='range']::-moz-range-thumb {border-color:#28375a;}input[type='range']::-webkit-slider-thumb {border-color:#28375a;}.mejs-controls .mejs-time-rail .mejs-time-current {background:#5a00f0 !important;}.plyr--video .plyr__control.plyr__tab-focus, .plyr--video .plyr__control:hover, .plyr--video .plyr__control[aria-expanded=true], .plyr__control--overlaid {background:#ffffff;color:#1e3c78;}.plyr--video .plyr__control.plyr__tab-focus, .plyr__control--overlaid:hover {box-shadow:0 0 0 16px rgba(255,255,255,0.25), 0 0 0 32pxrgba(255,255,255,0.13);}.plyr--full-ui input[type=range] {color:#5a00f0;}.favorited .glyphicon-add {color:#5a00f0 !important;}p.comment-form-comment textarea, #edd_login_form .edd-input, #edd_register_form .edd-input, #edd_checkout_form_wrap input.edd-input, #edd_checkout_form_wrap textarea.edd-input, #edd_checkout_form_wrap select.edd-select,#edd_download_pagination a.page-numbers, #edd_download_pagination span.page-numbers, #edd_profile_editor_form input:not([type="submit"]), #edd_profile_editor_form select, #contact textarea,.wpcf7-form-control-wrap textarea, input[type="text"], input[type="email"], input[type="password"], .solid-input input, .common-paginav a.next,.common-paginav a.prev, #edd_download_pagination a.next, #edd_download_pagination a.prev, .fes-pagination a.page-numbers, .fes-pagination span.page-numbers, .fes-product-list-pagination-container a.page-numbers, .fes-product-list-pagination-containerspan.page-numbers, .fes-fields input[type=email], .fes-fields input[type=password], .fes-fields textarea, .fes-fields input[type=url], .fes-fields input[type=text], .fes-vendor-comment-respond-form textarea, .fes-fields select, textarea,.vendor--search--box input[type="text"], .download_category .select2-container--default .select2-selection--single,.fes-fields .mayosel-select, #edd_profile_editor_form .mayosel-select, div.fes-form .fes-el .fes-fields input[type=text], .download_category .select2-container, div.fes-form .fes-el .fes-fields input[type=password], div.fes-form .fes-el .fes-fields input[type=email], div.fes-form .fes-el .fes-fields input[type=url], div.fes-form .fes-el .fes-fields input[type=number], div.fes-form .fes-el .fes-fields textarea {border-width:2px;}#fes-product-list tbody tr, #fes-order-list tbody tr,#edd_user_paid_commissions_table tbody tr,#edd_user_revoked_commissions_table tbody tr,#edd_user_unpaid_commissions_table tbody tr {border-color:rgba(40,55,90,0.1);}.fes-ignore.button {border:solidrgba(40,55,90,0.25);border-width:2px;color:#28375a;}.fes-ignore.button:hover {background:#28375a;}.hover_effect_single, .hover_effect, figure.effect-dm2 figcaption {background-color:rgba(40,40,55,.8);color:#ffffff}figure.mayosis-fade-in figcaption {background-color:rgba(40,40,55,.8);color:#ffffff;}.button-fill-color {background-color:#ffffff;color:rgba(40,40,55,.8);}.download-count-hover, .product-hover-social-share .social-button a, .product-hover-social-share .social-button a i, .recent_image_block .overlay_content_center a, .fes--author--image--block .overlay_content_center a {color:#ffffff !important;}.overlay_content_center .live_demo_onh {border-color:#ffffff;color:#ffffff;}.overlay_content_center .live_demo_onh:hover {background-color:#ffffff;border-color:#ffffff;color:rgba(40,40,55,.8) !important;}.header-master, #mobileheader {background:rgba(255,255,255,0);}.fill .form-control, .stylish-input-group input, .search-field, .maxcollapse-open .maxcollapse-input {background:transparent;border-color:#1e0050;border-width:2px;}.main-header.header-transparent .header-content-wrap, .mobile-header.header-transparent, #mobileheader {background:rgba(255,255,255,0);}header.fixedheader .site-logo img.main-logo, header.fixedheader .center-logo img.main-logo, header.fixedheader#mobileheader .mobile-logo {opacity:0;display:none !important;}.fixedheader.main-header .site-logo .sticky-logo, .fixedheader.main-header .center-logo .sticky-logo, #mobileheader.fixedheader .sticky-logo {display:inline-block;opacity:1;}#mayosis-menu.msv-main-menu > ul > li > a:hover, .my-account-menu a:hover,.mayosis-option-menu > li > a:hover,.dropdown.cart_widget > a:hover {opacity:.5;} #mayosis-menu.mayosis-bottom-menu > ul > li > a:hover {opacity:.5;}.searchoverlay-button {color:#28375a;}.main-footer {padding-top:120px;padding-right:0px;padding-bottom:40px;padding-left:0px;}footer.main-footer {background:#1e0050;}footer.main-footer:after {background:url() 100% 100% no-repeat;}.main-blog-promo:after {background:url(https://themeplanet.club/wp-content/uploads/2018/04/ISO-Cube-Lines.png) 100% 100% no-repeat;}.default-product-template.product-main-header:after {background:url(https://teconce.com/mayosis-maindemo/wp-content/uploads/sites/4/2019/01/footer-shape.png) 100% 100% no-repeat;}footer.main-footer, .footer-text, .footer-sidebar ul li a, .without-bg-social a, .mx-widget-counter h2, .main-footer a, .main-footer ul li a {color:#ffffff;}.footer-widget-title, .footer-sidebar .widget-title {color:#ffffff;}.main-footer .sidebar-blog-categories ul li a, .main-footer .recent_post_widget a,.main-footer .recent_post_widget p, .main-footer .widget-products a, .main-footer .widget-products p, .main-footer .sidebar-blog-categories ul li {color:#ffffff !important;}.additional-footer, div.wpcf7-validation-errors, div.wpcf7-acceptance-missing {border-color:#ffffff;}.back-to-top {background-color:#ffffff;border-color:#ffffff;color:#1e0050;}footer .social-profile a {background:#04003d;}.copyright-footer {background:#04003d;color:#ffffff;}.copyright-text, .copyright-footer a {color:#ffffff;}.footer-widget .sidebar-theme .single-news-letter .nl__item--submit {background-color:#ffffff;border-color:#ffffff;color:#1e0050;}.footer-widget input[type="text"], .footer-widget input[type="email"], .footer-widget input[type="password"], .footer-widget input[type="text"]::placeholder, .footer-widget input[type="email"]::placeholder, .footer-widget input[type="password"]::placeholder {color:#ffffff !important;}.footer-widget input[type="text"], .footer-widget input[type="email"], .footer-widget input[type="password"] {background:transparent !important;border-color:#ffffff !important;border-width:2px;}.theme--sidebar--widget .widget-title {color:#ffffff;}.theme--sidebar--widget .input-group.sidebar-search, .theme--sidebar--widget .search-field {margin:20px 0;}.sidebar-theme .search-form input[type=search], .sidebar-theme input[type=text], .sidebar-theme input[type=email], .sidebar-theme input[type=password], .sidebar--search--blog .search-form input[type=search], .theme--sidebar--widget select, .theme--sidebar--widget .search-field {border-color:#28375a;}.theme--sidebar--widget .menu-item a {color:#28375a;}.theme--sidebar--widget .single-news-letter .nl__item--submit {background-color:#28375a !important;border-color:#28375a !important;}.product_widget_inside, .sidebar-theme ul {padding:0;}.sidebar-blog-categories {padding:0;margin-bottom:30px;}.release-info {padding:0 !important;}.widget-title, .post-tabs .nav-pills > li.active > a, .post-tabs .nav-pills > li.active > a:focus, .post-tabs .nav-pills > li.active > a:hover, .sidebar-search #icon-addon,.theme--sidebar--widget .widget-title,.widget_block .wp-block-group__inner-container h2 {background:#1e0046;}.sidebar-search #icon-addon {color:#ffffff;}.solid--buttons-fx a {background:#1e0046 !important;border-color:#1e0046 !important;color:#ffffff !important;}.ghost--buttons-fx a {border-color:rgba(30,0,70,0.25) !important;color:#1e0046 !important;}.ghost--buttons-fx a:hover {background:#1e0046 !important;border-color:#1e0046 !important;color:#ffffff !important;}.sidebar-theme .search-form input[type=search], .sidebar-theme input[type=text], .sidebar-theme input[type=email], .sidebar-theme input[type=password], .sidebar--search--blog .search-form input[type=search], .theme--sidebar--widget select {background-color:transparent;border-color:#1e0050;border-width:2px;color:#28375a;}.sidebar-theme .single-news-letter .nl__item--submit {background:#1e0050;border-color:#1e0050;color:#ffffff;}.product-box, .grid_dm figure, .product-masonry-item .product-masonry-item-content, .grid-product-box .product-thumb img, .product-thumb {border-radius:3px;}.product-box, .dm-default-wrapper .edd_download_inner, .product-masonry-item .product-masonry-item-content {background:rgba(255,255,255,0);}.product-meta {padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;}.product-box .product-meta a, .product-box .product-meta, .product-box .count-download, .product-box .count-download .promo_price, .count-download span {color:#28375a;}.default-product-template.product-main-header {background:linear-gradient(135deg, #1e0064, #1e0046) !important;}.default-product-template.product-main-header .featuredimagebg {filter:blur(5px);transform:scale(1.1);}.default-product-template.product-main-header .featuredimagebg {transform:translateX(1px) scale(1.1);background-attachment:fixed !important;}.prime-product-template.product-main-header {background:#edf0f7 !important;}.prime-product-template.product-main-header .featuredimagebg {filter:blur(5px);transform:scale(1.1);}.prime-product-template.product-main-header,.prime-product-template.product-main-header .single_main_header_products,.prime-product-template.product-main-header .single_main_header_products h1,.prime-product-template.product-main-header .single_main_header_products span,.prime-product-template.product-main-header .single_main_header_products span a,.prime-product-template.product-main-header .single_main_header_products a,.prime-product-template.product-main-header .breadcrumb {color:#ffffff}.product-archive-breadcrumb, .product-archive-breadcrumb .parchive-page-title,.product-archive-breadcrumb .breadcrumb{color:#ffffff;text-align:center;}.product-archive-breadcrumb {background:linear-gradient(-135deg, #1e0046, #1e0064);} .featuredimageparchive {filter:blur(5px);transform:scale(1.1);}.product-archive-breadcrumb:before { content:"";transform:translateX(1px) scale(1.1);}.photo-video-template {background:#e9ebf7;}.main-post-promo, .single_author_box, .archive_bredcrumb_header {background:linear-gradient(-135deg, #1e0046, #1e0064);}.featuredimagebgblog {filter:blur(10px);transform:scale(1.1);}.featuredimagebgblog {transform:translateX(1px) scale(1.1);background-attachment:fixed !important;}.main-post-promo .single--post--content a, .single--post--content, .main-post-promo h1.single-post-title, .product-style-one-meta, .product-style-one-meta a, .main-post-promo .single-user-info ul li.datearchive, .main-post-promo .single-post-breadcrumbs .breadcrumb a, .main-post-promo .single-user-info ul li a, .single-post-excerpt, .main-post-promo .single-social-button, .main-post-promo .single-social-button a i, .single-post-breadcrumbs .breadcrumb > .active, .main-post-promo .blog--layout--contents,.main-post-promo .blog--layout--contents a,.main-post-promo .datearchive {color:#ffffff !important;}.breadcrumb > .active {color:#ffffff;}.comment-button a.btn, .social-button {color:#ffffff;}.comment-button a.btn:hover {background-color:#ffffff !important;border-color:#ffffff !important;color:#000046 !important;}.ie8 .lblue, .lblue > span, .lblue.left-corner > span::before, .lblue.left-corner > span::after, .lblue.right-corner > span, .lblue.right-corner > span::before, .lblue.right-corner > span::after {background-color:#e6174b;background-image:-webkit-gradient(linear, left top, left bottom, from(#e6174b), to(#e6174b)) !important;background-image:-webkit-linear-gradient(top, #e6174b,#e6174b) !important;background-image:-moz-linear-gradient(top, #e6174b, #e6174b) !important;background-image:-ms-linear-gradient(top, #e6174b, #e6174b) !important;background-image:-o-linear-gradient(top, #e6174b, #e6174b) !important;background-image:linear-gradient(to bottom, #e6174b, #e6174b) !important;}.lblue.left-edge::before {border-left-color:#b7133d !important;border-top-color:#b7133d !important;}.page_breadcrumb, .single_author_box, .archive_bredcrumb_header {padding-top:195px;padding-bottom:117px;padding-right:0px;padding-left:0px;}.main-post-promo, .product-archive-breadcrumb, .tag_breadcrumb_color {padding-top:180px;padding-bottom:120px;padding-right:0px;padding-left:0px;}.photo-video-template {padding-top:80px;padding-bottom:80px;padding-right:0px;padding-left:0px;}.default-product-template.product-main-header {padding-top:180px;padding-bottom:120px;padding-right:0px;padding-left:0px;}.prime-product-template.product-main-header {padding-top:80px;padding-bottom:80px;padding-right:0px;padding-left:0px;}.default-product-template.product-main-header,.default-product-template.product-main-header .single_main_header_products,.default-product-template.product-main-header .single_main_header_products h1,.default-product-template.product-main-header .single_main_header_products span a, .default-product-template.product-main-header .single_main_header_products span,.default-product-template.product-main-header .single_main_header_products a, .default-product-template.product-main-header .single_main_header_products .social-button span {color:#ffffff}.custombuttonmain.btn {background:#3c465a !important;border-color:#3c465a !important;}.grid-testimonal-promo .testimonial_details {background:#5a00f0;}.arrow-down {border-top-color:#5a00f0;}.load-mayosis {background:linear-gradient(135deg, #5a0096, #00003c);}.loading.reversed li {background-color:#5a0096;}.bottom_meta p a, .bottom_meta a {border-color:rgba(40,55,90,0.25);color:#28375a;}.bottom_meta p a:hover, .bottom_meta a:hover {background-color:#28375a;}.download_cat_filter, .search-btn::after, .download_cat_filter select option {background-color:#5a00f0;color:#ffffff;}.download_cat_filter:after {color:#ffffff;}.product-search-form select {color:#ffffff;}.product-search-form .search-fields {background-color:#ffffff;}.product-search-form.style2 input[type="text"] {border-color:#ffffff}.product-search-form input[type="text"] {border-color:#5a00f0;}@media (min-width:768px){.photo-template-author, .photo--section--image img {max-height:750px;}.photo--section--image {height:750px;}}@media (max-width:767px) {.photo--section--image{height:auto !important;}.photo-credential{margin:0 -5px;}.photo-credential {min-height:550px !important;} }@media (min-width:768px){ .photo--template--author--meta {position:absolute;}}.photo-credential {min-height:750px;} .photo--template--button {border-color:rgba(30,0,80,0.25);color:rgba(30,0,80,0.5);}.page_breadcrumb.mayosis-global-breadcrumb-style ,.common-page-breadcrumb.page_breadcrumb{background:#000046;}#edd_user_history td,table#edd_purchase_receipt_products td {border-color:rgba(40,55,90,0.25) !important;}.vendor--search--box .search-btn::after {color:rgba(40,55,90,0.65) !important;}.elementor-section.elementor-section-boxed > .elementor-container {max-width:1170px;}@media (min-width:1400px) {.elementor-section.elementor-section-boxed > .elementor-container {max-width:1170px;}.container { max-width:1170px;}footer.main-footer .container { max-width:1170px;}}.mayosis-video-url {height:100%;}.video-inner-box-promo .mejs-controls {opacity:0 !important;transition:all 0.5s ease;display:none !important;visibility:hidden !important;}.tag_breadcrumb_color {background:linear-gradient(-135deg,#1e0046 ,#1e0064 );}.mayosis-gradient-bar{background:linear-gradient(-135deg,#1e0046 ,#1e0064 );}.mayosis-custom-bar {} .mayosis-sticky-cart-gradient#mayosis-sticky-cart-bar{background:linear-gradient(-135deg,#1e0046 ,#1e0064 );}.mayosis-sticky-cart-custom#mayosis-sticky-cart-bar {}.maysosis-audio_hero {background:#000046 !important;}.maysosis-audio_hero .featuredimagebg {filter:blur(5px);transform:scale(1.1);} @media (min-width:768px){header.sticky,.header-master .to-flex-row,.main-header.maxcollapse,.maxcollapse-icon, .maxcollapse-submit{height:100px;}.header-master .to-flex-row {padding-top:60px;padding-right:0px;padding-bottom:0;padding-left:0px;}.footer-widget.mx-one{width:30%;}.footer-widget.mx-two{width:25%;}.footer-widget.mx-three{width:20%;}.footer-widget.mx-four{width:25%;}.footer-widget.mx-five{width:26%;}.footer-widget.mx-six{width:16%;}}</style><style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>			<style type="text/css">
				/* If html does not have either class, do not show lazy loaded images. */
				html:not( .jetpack-lazy-images-js-enabled ):not( .js ) .jetpack-lazy-image {
					display: none;
				}
			</style>
			<script>
				document.documentElement.classList.add(
					'jetpack-lazy-images-js-enabled'
				);
			</script>
		<style type="text/css" id="wp-custom-css">.button-extra-padding{
padding: 12px 53px !important;
}
.single-post-block h1, .single-post-block h2, .single-post-block h3, .single-post-block h4, .post-main-content h1, .post-main-content h2, .post-main-content h3 {
    margin-top: 0 !important;
    margin-bottom: 20px !important;
}
.dm_clients ul li{
	padding:0 10px;
}

#mayosis-menu > ul > li > a:hover, .my-account-menu a:hover, .mayosis-option-menu > li > a:hover, .dropdown.cart_widget > a:hover{
	color:#fff !important;
}
.edd-pruchase--conformation--message{
	display:none
}
.edd-download .single-post-block{
	display:block;
	overflow:hidden;
}
.extra__text{
	display:none;
}

a.paddle_button.pay-popup.paddle_styled_button.green {
    line-height: 1.8;
}
.product-cart-flex-button{
	display:none;
}

.free_download_block {
        justify-content: flex-start;
        margin-bottom: 0;
        display: none;
    }</style><style id="kirki-inline-styles">.cart-style-one .cart-button .edd-cart-quantity, .cart_top_1 > .navbar-nav > li > a.login-button, .main-header .login-button:hover,.sidemenu-login .login-button, .header-search-form .download_cat_filter, .header-search-form .search-btn::after, header .product-search-form .mayosis_vendor_cat{background:#5a00f0;}.cart-style-one .cart-button .edd-cart-quantity, .cart_top_1 > .navbar-nav > li > a.login-button, .main-header .login-button:hover,.sidemenu-login .login-button, .header-search-form .download_cat_filter, .header-search-form .search-btn::after, header .product-search-form .mayosis_vendor_cat,.header-search-form input[type="text"],.product-search-form.header-search-form input[type="text"]{border-color:#5a00f0;}.cart-style-one .cart-button .edd-cart-quantity, .cart_top_1 > .navbar-nav > li > a.login-button, .main-header .login-button:hover,.sidemenu-login .login-button, .header-search-form .download_cat_filter, .header-search-form .search-btn::after, header .product-search-form .mayosis_vendor_cat,header .product-search-form .mayosel-select .current{color:#ffffff;}.header-master #mayosis-menu > ul > li > a,.header-master ul li.cart-style-one a.cart-button,.header-master ul li a.cart-button,.header-master .search-dropdown-main a,.main-header .maxcollapse,.maxcollapse-icon, .maxcollapse-submit,.header-master .my-account-menu > a{line-height:100px;}.mayosis-option-menu li a i, .mayosis-option-menu li i, .desktop-hamburger-item i, #mayosis-menu ul li a i{font-size:13px;}.header-master,.header-master > a{color:#ffffff;}.header-top .to-flex-row{height:40px;}.header-top #mayosis-menu > ul > li > a,.header-top #top-main-menu > ul > li > a,.header-top ul li.cart-style-one a.cart-button, .header-top .mayosis-option-menu li{line-height:40px;}.header-top{background:#ffffff;}.header-top .to-flex-row,.header-top .burger{color:#28375a;}#top-main-menu > ul > li > a ,.top-header #cart-menu li a,.header-top #mayosis-menu > ul > li > a,.header-top #top-main-menu > ul > li > a,.header-top ul li.cart-style-one a.cart-button, .header-top .mayosis-option-menu li, #top-main-menu > ul > li > a > i , .top-header #cart-menu li a i,#top-main-menu ul li a i,.top-cart-menu li a i, .top-cart-menu li i,.header-top .to-flex-row i,.header-top .menu-item a{color:#28375a;}#top-main-menu ul ul a,.header-top .dropdown-menu li a,.header-top .mini_cart .widget .cart_item.empty .edd_empty_cart{color:#ffffff;}.header-top .mayosis-option-menu .mini_cart, #top-main-menu ul ul a,.header-top .mayosis-option-menu .my-account-list{background:#1e1e2d;}#top-main-menu ul ul:before,.header-top .cart_widget .mini_cart:before,#top-main-menu ul ul:after, .header-top .cart_widget .mini_cart:after,.header-top .mayosis-option-menu .my-account-list:before,.header-top .mayosis-option-menu .my-account-list:after{border-bottom-color:#1e1e2d;}#top-main-menu > ul > li > a > i , .top-header #cart-menu li a i,#top-main-menu ul li a i,.top-cart-menu li a i, .top-cart-menu li i,.header-top .to-flex-row i{font-size:12px;}.header-bottom{height:40px;background:#ffffff;color:#28375a;}.header-bottom,.header-bottom #mayosis-menu>ul>li>a{line-height:40px;}header .sticky,header .fixedheader{background:#ffffff;}.fixedheader a.mobile-cart-button,header .fixedheader #mayosis-menu > ul > li > a,header .fixedheader .cart-button, header .fixedheader .search-dropdown-main a,.sticky #mayosis-menu > ul > li > a,.sticky .cart-button, .sticky .search-dropdown-main a, header .fixedheader .cart-style-two .cart-button, .sticky .cart-style-two .cart-button,header .fixedheader .searchoverlay-button, .sticky .searchoverlay-button, header .fixedheader #menu-toggle, header .fixedheader .mobile_user > .navbar-nav > li > a, .sticky .mobile_user > .navbar-nav > li > a,.fixedheader .nav-style-megamenu>li.nav-item .nav-link, header.fixedheader .login-button, .header-master.fixedheader .mayosis-option-menu.d-none > .menu-item > a, .header-master.fixedheader .login-button,.fixedheader .header-ghost-form.header-search-form .mayosel-select .current,.fixedheader .header-ghost-form.header-search-form input[type="text"]::placeholder,.fixedheader .header-ghost-form.header-search-form .mayosel-select:after,.fixedheader .header-ghost-form.header-search-form .search-btn::after{color:#28375a;}header .fixedheader #menu-toggle,header .fixedheader .mobile_user > .navbar-nav > li > a, .sticky .mobile_user > .navbar-nav > li > a, .header-master.fixedheader .login-button,.fixedheader .header-ghost-form.header-search-form input[type="text"],.fixedheader .header-ghost-form.header-search-form .mayosel-select{border-color:#28375a;}header .fixedheader .burger span, header .fixedheader .burger span::before, header .fixedheader .burger span::after{background-color:#28375a;}.burger span, .burger span::before, .burger span::after,.burger.clicked span:before, .burger.clicked span:after{background-color:#ffffff;}a.mobile-cart-button{color:#ffffff;}#menu-toggle,.mobile--nav-menu > .navbar-nav > li > a, #sidebar-wrapper .navbar-nav > li > a, #sidebar-wrapper #mega-menu-wrap-main-menu #mega-menu-main-menu > li.mega-menu-item > a.mega-menu-link,.mobile--nav-menu a,#sidebar-wrapper .dropdown-menu > li > a,.mobile--nav-menu a, .mobile--nav-menu>#mayosis-sidemenu>ul>li>a,.mobile--nav-menu ,.mobile--nav-menu .menu-item a,.mobile-menu-main-part #mayosis-sidemenu a,.top-part-mobile a,.bottom-part-mobile a,.overlay_button_search{color:#ffffff;}#menu-toggle,.mobile_user > .navbar-nav > li > a,.mobile--nav-menu .holder::after{border-color:#ffffff;}#mayosis-sidemenu > ul > li > a:hover, #mayosis-sidemenu > ul > li.active > a, #mayosis-sidemenu > ul > li.open > a{background:#ffffff;color:#000;}#mayosis-menu > ul > li > a,.header-master .main-header ul li.cart-style-one a.cart-button,.search-dropdown-main a,.header-master .menu-item a,.header-master .cart-style-two .cart-button,.my-account-list>li>a ,.header-master .burger,.header-master .cart-button, .cart_top_1>.navbar-nav>li>a.cart-button,.header-master .my-account-menu a,.header-master .searchoverlay-button{color:#ffffff;}#mayosis-menu > ul > li > a:hover, .my-account-menu a:hover,.mayosis-option-menu > li > a:hover,.dropdown.cart_widget > a:hover{color:#28375a;}#mayosis-menu ul ul,.search-dropdown-main ul,.mayosis-option-menu .mini_cart,#mayosis-sidemenu > ul > li > a:hover, .my-account-menu .my-account-list{background:#5000ce;}.search-dropdown-main ul:after,.header-master .mayosis-option-menu .mini_cart:after,.header-master .my-account-menu .my-account-list:after,#mayosis-menu ul ul:before{border-bottom-color:#5000ce;}#mayosis-menu ul ul,.header-master .dropdown-menu li a,#mayosis-menu ul ul a,.header-master.fixedheader .dropdown-menu li a, .edd-cart-item-quantity, .edd-cart-item-title,.mini_cart .widget .edd-cart-item-price,.mini_cart .widget .edd-remove-from-cart,.mini_cart .widget .cart_item.empty .edd_empty_cart, .widget_edd_cart_widget.cart-empty .cart_item.empty, .edd-cart-item-quantity, .edd-cart-item-title,.mini_cart .widget .edd-cart-item-price,.cart_item.edd-cart-meta.edd_total, .mini_cart .cart_item.edd-cart-meta.edd_subtotal, .mini_cart .edd-cart-meta.edd_cart_tax{color:#ffffff;}#mayosis-menu ul ul,.header-master .dropdown-menu li a:hover,#mayosis-menu ul ul a:hover,.header-master.fixedheader .dropdown-menu li a:hover{color:#ffffff;}.xoopic-m-menu .nav-style-megamenu>li.nav-item .dropdown-menu .submenu-box{background:#fff;}.nav-style-megamenu>li.nav-item .dropdown-menu .xoopic-mg-col-title{color:#28375a;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:1rem;font-weight:700;line-height:1.75;}.nav-style-megamenu>li.nav-item .dropdown-menu .xoopic-mg-col-title:hover{color:#28375a;}.nav-style-megamenu>li.nav-item .dropdown-menu .dropdown-item{color:#28375a;}.nav-style-megamenu>li.nav-item .dropdown-menu .dropdown-item:hover{color:#28375a;}.header-bottom #mayosis-menu>ul>li>a,.header-bottom ul li.cart-style-one a.cart-button,.header-bottom .my-account-menu a, #mayosis-menu.mayosis-bottom-menu>ul>li>a{color:#28375a;}.header-bottom #mayosis-menu ul ul a,.header-bottom #mayosis-menu ul ul, .header-bottom .search-dropdown-main ul,.header-bottom .mayosis-option-menu .mini_cart,.header-bottom #mayosis-sidemenu > ul > li > a:hover, .header-bottom #mayosis-sidemenu > ul > li.active > a, .header-bottom #mayosis-sidemenu > ul > li.open > a,.header-bottom .my-account-menu .my-account-list,.header-bottom .my-account-list a,#mayosis-menu.mayosis-bottom-menu ul ul a{color:#ffffff;}.header-bottom #mayosis-menu ul ul, .header-bottom .search-dropdown-main ul,.header-bottom .mayosis-option-menu .mini_cart,.header-bottom #mayosis-sidemenu > ul > li > a:hover, .header-bottom #mayosis-sidemenu > ul > li.active > a, .header-bottom #mayosis-sidemenu > ul > li.open > a,.header-bottom .my-account-menu .my-account-list, #mayosis-menu.mayosis-bottom-menu ul ul{background:#1e1e2d;}.header-bottom #mayosis-menu ul ul:before,.header-bottom .mayosis-option-menu .mini_cart:after,.header-bottom .my-account-menu .my-account-list:after, #mayosis-menu.mayosis-bottom-menu ul ul:before{border-bottom-color:#1e1e2d;}.stylish-input-group input.dm_search,.mayosis-offcanvas-box .search input[type="search"]{border-top-left-radius:0px;border-top-right-radius:0px;border-bottom-left-radius:0px;border-bottom-right-radius:0px;background-color:#e9edf7;border-color:#e9edf7;}.stylish-input-group input.dm_search,.stylish-input-group i,.stylish-input-group input::placeholder,.mayosis-offcanvas-box .search input[type="search"]{color:#282837;}.header-search-form{width:360px;}.header-search-form input[type=search], .header-search-form input[type=text], .header-search-form select,.header-search-form .search-btn, .header-search-form .mayosel-select,.header-search-form .search-btn::after,.header-minimal-form .search-fields{height:40px;max-height:40px;}.header-search-form .search-btn::after,.header-minimal-form .search-fields{line-height:40px;}.header-ghost-form.header-search-form input[type="text"],.header-ghost-form.header-search-form .mayosel-select,.header-ghost-form.header-search-form select, .header-ghost-form.header-search-form .download_cat_filter,.header-minimal-form{border-color:rgba(40,55,90,0.25);}.header-ghost-form.header-search-form input[type="text"],.header-ghost-form.header-search-form .mayosel-select .current,.header-ghost-form.header-search-form select,.header-ghost-form.header-search-form .mayosel-select:after,.header-ghost-form.header-search-form .search-btn::after,.header-ghost-form.header-search-form input[type="text"]::placeholder,.header-minimal-form,.header-minimal-form input,.header-minimal-form input[type="text"]::placeholder,.header-minimal-form.header-search-form .search-btn::after{color:rgba(40,55,90,1);}.header-ghost-form.header-search-form .mayosel-select,.header-ghost-form.header-search-form select{-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px;}.header-ghost-form.header-search-form input[type="text"],header .search-btn::after{border-top-right-radius:3px;border-bottom-right-radius:3px;}.top-social-icon li a{color:#3d3d3d;font-size:12px;}.top-social-icon li a:hover{color:#3d3d3d;}.mayosis-logout-information,.msv-wallet-value{border-color:#29293e;}.mayosis-account-user-information, .mayosis-logout-information > a.mayosis-logout-link, .header-top .mayosis-logout-information > a.mayosis-logout-link, .mayosis-logout-information > a.mayosis-logout-link i, .header-top .mayosis-logout-information > a.mayosis-logout-link i, .dropdown-menu.my-account-list a,.dropdown-menu.my-account-list li a, .dropdown-menu.my-account-list a i,.msv-wallet-value{color:#fff;}.mayosis-account-user-information img{border-top-left-radius:0;border-top-right-radius:0;border-bottom-left-radius:0;border-bottom-right-radius:0;}.msv-mobile-pop-account .btn,.msv-mob-login-menu a{background:#29293e;color:#fff;}.msv-mobile-pop-account .dropdown-menu{background:#29293e;}.msv-mobile-pop-account .dropdown-menu,.msv-mobile-pop-account .dropdown-menu a{color:#ffffff;}#mayosis-sidebar .mayosis-sidebar-header{background-color:#26264d;}#mayosis-sidebar,#mayosis-sidebar .sidebar-fixed{background-color:#ffffff;}.sidebar-main-logo img{margin-top:0;margin-bottom:0;margin-left:0;margin-right:0;}#mayosis-sidebar .social-icon-sidebar-header{background-color:#26264d;}#mayosis-sidebar .social-icon-sidebar-header a{color:#ffffff;}.social-icon-sidebar-header{padding-top:0;padding-bottom:0;padding-left:0;padding-right:0;}#mayosis-sidebar .burger span,#mayosis-sidebar .burger span::before,#mayosis-sidebar .burger span::after,#mayosis-sidebar .burger.clicked span:before,#mayosis-sidebar .burger.clicked span:after{background:#ffffff;}body,.fes-form.fes-submission-form-div,.fes-fields table,#fes-vendor-dashboard table,#fes-product-list tbody tr td,.fes-profile-form{background:#ffffff;}.fes-form.fes-submission-form-div,.fes-fields table,#fes-vendor-dashboard table,#fes-product-list tbody tr td,.fes-profile-form{border-color:#ffffff;}.bottom-post-footer-widget,.post-view-style,.post-promo-box,.author_meta_single,.single_author_post,.sidebar-product-widget,.single-blog-widget,artist-items, blockquote,table,pre, .fes-fields textarea,.jssortside,#mayosisone_1,#mayosis_side,.photo--price--block a.edd-wl-action.edd-wl-button,.photo--price--block .photo_edd_el_button,.mayosis-account-information{background:#e9edf7;}table#edd_purchase_receipt, table#edd_purchase_receipt_products,table,pre,code,.photo--price--block a.edd-wl-action.edd-wl-button,.photo--price--block .photo_edd_el_button{border-color:#e9edf7;}.mayosis-account-information,.mayosis-account-information a,.mayosis-account-information a.mayosis-logout-link{color:#171f33;}.select2Buttons a:hover, .select2Buttons .picked,.acf-button,#commentform input[type=submit],.slider_dm_v .carousel-indicators .active, #edd-purchase-button,.edd-submit,input.edd-submit[type="submit"], .dm_register_button,.back-to-top:hover,button.fes-cmt-submit-form,.mini_cart .cart_item.edd_checkout a,.photo-image-zoom, a.edd-wl-button.edd-wl-save.edd-wl-action, .wishlist-with-bg .edd-wl-button.edd-wl-action, .edd-wl-create input[type=submit],nav.fes-vendor-menu ul li.active::after, .edd-wl-item-purchase .edd-add-to-cart-from-wish-list,.button-sub-right .btn,.fes-product-list-td a, .upload-cover-button, .wpcf7-submit,.status-publish.sticky:before, .footer-link-page-post .footer-page-post-link,.lSSlideOuter .lSPager.lSpg > li:hover a, .lSSlideOuter .lSPager.lSpg > li.active a,.lSSlideOuter .lSPager.lSpg > li a,.edd-submit.button.blue, .single-cart-button a.btn, .edd_purchase_submit_wrapper a.edd-add-to-cart.edd-has-js, .single-news-letter .nl__item--submit:hover,.edd-submit.button.blue:hover, .single-cart-button a:hover.btn, .edd_purchase_submit_wrapper a.edd-add-to-cart.edd-has-js:hover,#commentform input[type=submit]:hover,#sidebar-wrapper a#menu-close,#sidebar-wrapper a#menu-close:hover,.mini_cart .main_widget_checout,#basic-user-avatar-form input[type="submit"],#edd_profile_editor_submit,#basic-user-avatar-form input[type="submit"]:hover,#edd_profile_editor_submit:hover,.styleone.btn,.single-product-buttons .multiple_button_v,.button_accent,.fes-url-choose-row .edd-submit.upload_file_button,table.multiple tfoot tr th .edd-submit.insert-file-row,.edd-submit.button.blue.active, .edd-submit.button.blue:focus, .edd-submit.button.blue:hover,.subscribe-block-btn,div.fes-form .fes-submit input[type=submit],.fes--author--buttonbox .btn.fes--box-btn,.overlay-btn.overlay-btn-style-3 a.edd-wl-action.edd-wl-button:hover,.overlay-btn.overlay-btn-style-3 .edd_purchase_submit_wrapper .button.edd-submit:hover,.popr_content,.mayosis-style-two-player.mayosis-title-audio,.title--button--box .btn.title--box--btn,.edd-submit.button, .edd-submit.button.gray, .edd-submit.button:visited,#edd-custom-deliverables-email-customer{background:#5a00f0;}.select2Buttons a:hover, .select2Buttons .picked,.select2Buttons li a, .select2Buttons .limited a, .select2Buttons .disabled,.acf-button,#commentform input[type=submit],.slider_dm_v .carousel-indicators .active, #edd-purchase-button,.edd-submit,input.edd-submit[type="submit"], .dm_register_button,.back-to-top:hover,button.fes-cmt-submit-form,.mini_cart .cart_item.edd_checkout a,.photo-image-zoom, a.edd-wl-button.edd-wl-save.edd-wl-action, .wishlist-with-bg .edd-wl-button.edd-wl-action, .edd-wl-create input[type=submit], .edd-wl-item-purchase .edd-add-to-cart-from-wish-list,.carousel-indicators li,blockquote, #wp-calendar caption,.edd_discount_link, #edd-login-account-wrap a, #edd-new-account-wrap a,.edd-submit.button.blue, .single-cart-button a.btn, .edd_purchase_submit_wrapper a.edd-add-to-cart.edd-has-js, .single-news-letter .nl__item--submit:hover,.edd-submit.button.blue:hover, .single-cart-button a:hover.btn, .edd_purchase_submit_wrapper a.edd-add-to-cart.edd-has-js:hover,#commentform input[type=submit]:hover,#sidebar-wrapper a#menu-close,#sidebar-wrapper a#menu-close:hover,.mini_cart .main_widget_checout,#basic-user-avatar-form input[type="submit"],#edd_profile_editor_submit,#basic-user-avatar-form input[type="submit"]:hover,#edd_profile_editor_submit:hover,.styleone.btn,.single-product-buttons .multiple_button_v,.button_accent,.fes-url-choose-row .edd-submit.upload_file_button,table.multiple tfoot tr th .edd-submit.insert-file-row,.edd-submit.button.blue.active, .edd-submit.button.blue:focus, .edd-submit.button.blue:hover,div.fes-form .fes-submit input[type=submit],.fes-submit .edd-submit.blue.button,.fes--author--buttonbox .btn.fes--box-btn,.subscribe-box-photo,.edd-submit.button, .edd-submit.button.gray, .edd-submit.button:visited,#edd-custom-deliverables-email-customer,input[type="submit"]{border-color:#5a00f0;}.select2Buttons li a, .select2Buttons .limited a, .select2Buttons .disabled,.hide-if-value .acf-button.button,.post-viewas> .nav-pills>li.active>a, .post-viewas>.nav-pills>li.active>a:focus, .post-viewas>.nav-pills>li.active>a:hover,.fourzerofour-info a,a:hover, .sidebar-blog-categories ul li:hover, .sidebar-blog-categories ul li:hover a,.dm_comment_author a, .single-user-info ul li:first-child a:hover,.mayosis-popup .close:hover,.edd_price_options.edd_single_mode ul li label input:checked~span.edd_price_option_name:before,.user-info a:hover,.product-title a:hover,.sidebar-blog-categories ul li:hover, .post-promo-box .single-blog-title a:hover, .edd_download_purchase_form .edd_price_options li.item-selected label,nav.fes-vendor-menu ul li.active a:before, nav.fes-vendor-menu ul li.active a, nav.fes-vendor-menu ul li:hover a, .favorited .glyphicon-add,.mayosel-select .option.selected,#today a,#edd_payment_mode_select_wrap input[type="radio"]:checked::before,.edd_cart_footer_row .edd_cart_total,#edd_checkout_form_wrap input[type=radio]:checked::before, #wp-calendar caption,.edd_discount_link, #edd-login-account-wrap a, #edd-new-account-wrap a,.main-post-promo .single-user-info ul li a:hover,.post-viewas> .nav-pills>li.active>a,.post-viewas> .nav-pills>li>a:hover,.button_ghost.button_accent,.button_link.button_accent,.button_ghost.button_accent:hover,.block-hover:hover,.main_content_licence.youcan table tr td .icon-background1 ,.edd_price_options.edd_single_mode ul li label input:checked~span.edd_price_option_name:before,.edd_price_options.edd_multi_mode ul li label input:checked~span.edd_price_option_name:before,.favorited .glyphicon-add,.popr_content>#mayosis-sidemenu>ul>li>a:hover,.popr_content> #mayosis-sidemenu > ul > li.active > a,#edd-custom-deliverables-email-customer{color:#5a00f0;}.common-paginav a.next:hover,.common-paginav a.prev:hover,.common-paginav a.page-numbers:hover, .common-paginav span.page-numbers:hover,#edd_download_pagination a.page-numbers:hover,#edd_download_pagination span.page-numbers:hover,#edd_download_pagination span.page-numbers.current:hover,.button-fill-color:hover,.licence_main_title.youcantitle,input[type="submit"],input[type="submit"].wpcf7-submit{background:#5a00f0;}.common-paginav a.next:hover,.common-paginav a.prev:hover,.common-paginav a.page-numbers:hover, .common-paginav span.page-numbers:hover,#edd_download_pagination a.page-numbers:hover,#edd_download_pagination span.page-numbers:hover,#edd_download_pagination span.page-numbers.current:hover,p.comment-form-comment textarea:focus,#commentform input[type=text]:focus, #commentform input[type=email]:focus, p.comment-form-comment textarea:focus,#edd_login_form .edd-input:focus, #edd_register_form .edd-input:focus,#edd_checkout_form_wrap input.edd-input:focus, #edd_checkout_form_wrap textarea.edd-input:focus,#edd_checkout_form_wrap select.edd-select:focus,#edd_profile_editor_form input:not([type="submit"]):focus,#edd_profile_editor_form select:focus,.dasboard-tab,#contact textarea:focus, .wpcf7-form-control-wrap textarea:focus,input[type="text"]:focus, input[type="email"]:focus, input[type="password"]:focus,.solid-input input:focus,.product-search-form input[type="text"]:focus, .product-search-form input[type="search"]:focus,.button-fill-color:hover,.licence_main_title.youcantitle,input[type="submit"].wpcf7-submit,.theme--sidebar--widget.product_subscription_package,.title--button--box .btn.title--box--btn{border-color:#5a00f0;}p.comment-form-comment textarea:hover,#commentform input[type=text]:hover, #commentform input[type=email]:hover, p.comment-form-comment textarea:hover,#edd_login_form .edd-input:hover, #edd_register_form .edd-input:hover,#edd_checkout_form_wrap input.edd-input:hover, #edd_checkout_form_wrap textarea.edd-input:hover,#edd_checkout_form_wrap select.edd-select:hover,#edd_profile_editor_form input:not([type="submit"]):hover,#edd_profile_editor_form select:hover,.dasboard-tab,#contact textarea:hover, .wpcf7-form-control-wrap textarea:hover,input[type="text"]:hover, input[type="email"]:hover, input[type="password"]:hover,.solid-input input:hover,.product-search-form input[type="text"]:hover, .product-search-form input[type="search"]:hover{border-bottom-color:#5a00f0;}.select2Buttons a:hover, .select2Buttons .picked,.acf-button,#commentform input[type=submit],.slider_dm_v .carousel-indicators .active, #edd-purchase-button,.edd-submit,input.edd-submit[type="submit"], .dm_register_button,.back-to-top:hover,button.fes-cmt-submit-form,.mini_cart .cart_item.edd_checkout a,.photo-image-zoom, a.edd-wl-button.edd-wl-save.edd-wl-action, .wishlist-with-bg .edd-wl-button.edd-wl-action, .edd-wl-create input[type=submit], .edd-wl-item-purchase .edd-add-to-cart-from-wish-list,header .product-search-form .mayosel-select .current, a.edd-wl-button.edd-wl-save.edd-wl-action span, .edd-wl-item-purchase .edd-add-to-cart-from-wish-list span,.fes-product-list-td a,.button-sub-right .btn,.upload-cover-button:hover, .wpcf7-submit,.status-publish.sticky:before, .footer-link-page-post,.upload-cover-button, .footer-page-post-link,.lSSlideOuter .lSPager.lSpg > li:hover a, .lSSlideOuter .lSPager.lSpg > li.active a,.lSSlideOuter .lSPager.lSpg > li a,.button_accent,input[type="submit"],input[type="submit"].wpcf7-submit,.fes-url-choose-row .edd-submit.upload_file_button,table.multiple tfoot tr th .edd-submit.insert-file-row,.edd-submit.button.blue.active, .edd-submit.button.blue:focus, .edd-submit.button.blue:hover,.subscribe-block-btn,div.fes-form .fes-submit input[type=submit],.fes--author--buttonbox .btn.fes--box-btn,.overlay-btn.overlay-btn-style-3 a.edd-wl-action.edd-wl-button:hover,.overlay-btn.overlay-btn-style-3 .edd_purchase_submit_wrapper .button.edd-submit:hover,.popr_content,.popr_content>#mayosis-sidemenu>ul>li>a,.edd-submit.button, .edd-submit.button.gray, .edd-submit.button:visited,#edd-custom-deliverables-email-customer{color:#ffffff;}.button_ghost.button_accent:hover,.block-hover:hover,.popr_content>#mayosis-sidemenu>ul>li>a:hover,.popr_content> #mayosis-sidemenu > ul > li.active > a,.mayosis-style-two-player.mayosis-title-audio .mejs-button>button{background:#ffffff;}.button_ghost.button_accent:hover,.block-hover:hover{border-color:#ffffff;}.edd-submit.button.blue, .single-cart-button a.btn,.photo-image-zoom:hover, .edd_purchase_submit_wrapper a.edd-add-to-cart.edd-has-js, .single-news-letter .nl__item--submit:hover,.edd-submit.button.blue:hover, .single-cart-button a:hover.btn, .edd_purchase_submit_wrapper a.edd-add-to-cart.edd-has-js:hover,#commentform input[type=submit]:hover,#sidebar-wrapper a#menu-close,#sidebar-wrapper a#menu-close:hover,.mini_cart .main_widget_checout,#basic-user-avatar-form input[type="submit"],#edd_profile_editor_submit,#basic-user-avatar-form input[type="submit"]:hover,#edd_profile_editor_submit:hover,.styleone.btn,.single-product-buttons .multiple_button_v,.button-fill-color:hover,.licence_main_title.youcantitle,.title--button--box .btn.title--box--btn{color:#ffffff;}.single_author_box,.overlay,h2#sitemap_pages,.mobile--nav-menu,.grid--download--categories a.cat--grid--main::after,.fes_dashboard_menu,.edd-fd-button,#edd_checkout_cart a.edd-cart-saving-button.edd-submit.button.blue,#edd_checkout_cart .edd-submit.button.blue,#menu-toggle:hover,a.mobile-cart-button:hover,a.mobile-login-button:hover,#sidebar-wrapper,.modal-backdrop,.mayosis-main-media .mejs-controls,.mayosis-main-media .mejs-container, #edd_checkout_cart a.edd-cart-saving-button.edd-submit.button.blue:hover,.fourzerofour-info, #edd_profile_name_label, #edd_profile_billing_address_label, #edd_profile_password_label, .styletwo.btn,.transbutton.btn:hover,.mayosisonet101,.social_share_widget a:hover,.social-button-bottom a:hover i, h2.reciept_heading,.fill .btn,#fes-comments-table tr.heading_tr,#fes-product-list thead,#edd_user_commissions_overview table tr th, #edd_user_commissions_paid thead tr th,#fes-order-list thead tr th, #edd_user_revoked_commissions_table thead tr th, #edd_user_unpaid_commissions_table thead tr th,.photo--template--button:hover,.title--button--box .btn.title--box--btn.transparent:hover,#mayosis-sidebar a[aria-expanded=true], #mayosis-sidebar ul li.active>a,.btn-file,.extended-dasboard-tab,.edd-go-to-checkout-from-wish-list.edd-wl-button{background:#1e0050;}.edd-fd-button,#edd_checkout_cart a.edd-cart-saving-button.edd-submit.button.blue,#edd_checkout_cart .edd-submit.button.blue,#menu-toggle:hover,a.mobile-cart-button:hover,a.mobile-login-button:hover,#sidebar-wrapper,.modal-backdrop,.mayosis-main-media .mejs-controls,.mayosis-main-media .mejs-container, #edd_checkout_cart a.edd-cart-saving-button.edd-submit.button.blue:hover,.fourzerofour-info, #edd_profile_name_label, #edd_profile_billing_address_label, #edd_profile_password_label, .styletwo.btn,.transbutton.btn:hover,.mayosisonet101,.social_share_widget a:hover,.social-button-bottom a:hover i, h2.reciept_heading,.fill .btn,#fes-comments-table tr.heading_tr,#fes-product-list thead,#edd_user_commissions_overview table tr th, #edd_user_commissions_paid thead tr th,#fes-order-list thead tr th, #edd_user_revoked_commissions_table thead tr th, #edd_user_unpaid_commissions_table thead tr th,.photo--template--button:hover,.transbutton.btn,.post-viewas> .nav-pills>li>a,.button_ghost.button_secaccent:hover,.btn-file,.edd-go-to-checkout-from-wish-list.edd-wl-button{border-color:#1e0050;}.transbutton.btn,.post-viewas> .nav-pills>li>a,.button_ghost.button_secaccent,.button_link.button_secaccent{color:#1e0050;}.button_secaccent{background-color:#1e0050;}.button_secaccent,.button_ghost.button_secaccent:hover{border-color:#1e0050;}#edd_checkout_cart a.edd-cart-saving-button.edd-submit.button.blue:hover,.fourzerofour-info, #edd_profile_name_label, #edd_profile_billing_address_label, #edd_profile_password_label, .styletwo.btn,.transbutton.btn:hover,.mayosisonet101,.social_share_widget a:hover,.social-button-bottom a:hover i, h2.reciept_heading,.fill .btn,#fes-comments-table tr.heading_tr,#fes-product-list thead,#edd_user_commissions_overview table tr th, #edd_user_commissions_paid thead tr th,#fes-order-list thead tr th, #edd_user_revoked_commissions_table thead tr th, #edd_user_unpaid_commissions_table thead tr th,.photo--template--button:hover, #searchoverlay .search input,#searchoverlay .search span,#searchoverlay .search input, #searchoverlay .search input::placeholder,#searchoverlay .close,.overlay,.title--button--box .btn.title--box--btn.transparent:hover,#mayosis-sidebar a[aria-expanded=true], #mayosis-sidebar ul li.active>a,.btn-file,.extended-dasboard-tab a,.extended-dasboard-tab ul li a,.edd-go-to-checkout-from-wish-list.edd-wl-button{color:#ffffff;}#searchoverlay .search input,#searchoverlay .search span,#searchoverlay .search input, #searchoverlay .search input::placeholder,#searchoverlay .close,.overlay{border-color:#ffffff;}h1.page_title_single,.sep,.page_breadcrumb .breadcrumb > .active,.page_breadcrumb .breadcrumb a,#menu-toggle:hover,a.mobile-cart-button:hover,a.mobile-login-button:hover,#sidebar-wrapper,.overlay_content_center a.overlay_cart_btn,.overlay_content_center a.overlay_cart_btn:hover,.widget-posts .overlay_content_center a i, .bottom-widget-product .overlay_content_center a i,.breadcrumb a,.breadcrumb > .active,.grid--download--categories a, nav.fes-vendor-menu ul li a,.button_secaccent,.button_ghost.button_secaccent:hover,.button_text,.button_ghost.button_text:hover{color:#ffffff;}body,h1,h2,h3,h4,h5,h6,a,.mayosis-play--button-video:focus,.mayosis-play--button-video,.mayosel-select,textarea,.title--button--box .btn.title--box--btn.transparent{color:#28375a;}.sidebar-theme ul li a,.bottom-widget-product a,.total-post-count p,.author_single_dm_box p, .author_single_dm_box a,.author_meta_single h2 a,.author_meta_single p,.author_meta_single a, .author_meta_single ul li a,.comment-content p,a.sigining-up,.edd-lost-password a,.edd-login-remember span,.promo_price,#edd_checkout_cart th,#edd_checkout_form_wrap legend,#edd_checkout_wrap #edd_checkout_form_wrap label, #edd_checkout_form_wrap span.edd-description,span.edd_checkout_cart_item_title,#edd_checkout_cart .edd_cart_header_row th,#edd_checkout_cart td,#edd_checkout_form_wrap input.edd-input, #edd_checkout_form_wrap textarea.edd-input, #edd_checkout_form_wrap span.edd-required-indicator,#edd_checkout_form_wrap select.edd-select,.single-user-info ul li a,.stylish-input-group button,.user-info span,.user-info a,.single_author_post,.empty_cart_icon i, .empty_cart_icon h2,.fourzerofour-area h1,.fourzerofour-area h3,#edd_profile_editor_form label,table tbody tr td,.mayosis-madalin .modal-header .close,.product-price h3,.sidebar-details p,.bottom-product-sidebar h4, .sidebar-blog-categories ul li a,.release-info .rel-info-value,.release-info .rel-info-tag,#edd_login_form .edd-input, #edd_register_form .edd-input,.grid-testimonal-promo .testimonial_details i.testimonial_queto_dm,.bottom_meta a, .dm_comment_author,.dm_comment-date,.comment--dot,.single-blog-title a,.single-blog-title,.top-header .top-social-icon li a:hover,code,.search-dropdown-main button,.post-promo-box.grid_dm .overlay_content_center a, .photo--price--block a.edd-wl-action.edd-wl-button,div.fes-form .fes-el .fes-label .fes-help,.fes-label label,.artist-items h3,.artist-items h3 a,.artist-items h3 a span{color:#28375a;}.section-title,.product-meta a:hover,.maxcollapse-open .maxcollapse-input,.maxcollapse-open .maxcollapse-input::placeholder, .maxcollapse-open .maxcollapse-icon,#edd_show_discount,#edd_final_total_wrap,.bottom-product-sidebar h4,.sidebar-details h3 a, .bottom-product-sidebar .sidebar-details p,.bottom-widget-product .product-price .edd_price,.sidebar-details h3,.sidebar-details h3 a, .sidebar-details p,.sidebar-blog-categories ul li a,.edd_price_options.edd_single_mode ul li label,.product-price h3,.single-user-info ul li a, .single-blog-title a,.single-blog-title,.user-info a,legend, pre, .header-search-form .download_cat_filter select option, .header-search-form .download_cat_filter:after,.prime-wishlist-fav a.edd-wl-action.edd-wl-button, .prime-wishlist-fav a.edd-wl-action.edd-wl-button:hover i,.prime-wishlist-fav a.edd-wl-action.edd-wl-button:hover span,.tag_widget_single ul li a,.sidebar-blog-categories ul li,#fes-save-as-draft{color:#28375a;}::-webkit-input-placeholder,::-moz-placeholder,#edd_checkout_form_wrap input.edd-input::placeholder,#edd_checkout_form_wrap textarea.edd-input::placeholder,#edd_login_form .edd-input::placeholder, #edd_register_form .edd-input::placeholder,sidebar-search input[type=search]::placeholder,.button_ghost.button_text,.button_link.button_text,nav.fes-vendor-menu ul li.active a{color:#28375a;}.icon-play{border-left-color:#28375a;}.ghost_button,.mayosel-select:after,#edd_user_history th,table#edd_checkout_cart tbody,#edd_checkout_cart input.edd-item-quantity,.rel-info-value p,.button_text,.button_ghost.button_text:hover,#fes-save-as-draft{border-color:#28375a;}.ghost_button:hover,.tag_widget_single ul li a:hover,.mayosis-title-audio .mejs-button>button,.button_text,.button_ghost.button_text:hover{background-color:#28375a;}#edd_download_pagination a.page-numbers, #edd_download_pagination span.page-numbers,.common-paginav a.next, .common-paginav a.prev, #edd_download_pagination a.next, #edd_download_pagination a.prev, .fes-pagination a.page-numbers, .fes-pagination span.page-numbers, .fes-product-list-pagination-container a.page-numbers, .fes-product-list-pagination-container span.page-numbers{border-top-left-radius:3px;border-top-right-radius:3px;border-bottom-left-radius:3px;border-bottom-right-radius:3px;}p a, a,.fes-widget--metabox a,.tabbable-line > .nav-tabs > li >a{color:#28375a;}p a:hover, a:hover,.fes-widget--metabox a:hover{color:#28375a;}#edd_download_pagination a.page-numbers, #edd_download_pagination span.page-numbers, .common-paginav a.next, .common-paginav a.prev, #edd_download_pagination a.next, #edd_download_pagination a.prev, .fes-pagination a.page-numbers, .fes-pagination span.page-numbers, .fes-product-list-pagination-container a.page-numbers, .fes-product-list-pagination-container span.page-numbers,.common-paginav a.page-numbers, .common-paginav span.page-numbers{color:#28375a;}.common-paginav a.next,.common-paginav a.prev,.common-paginav span.page-numbers.current,#edd_download_pagination a.next,#edd_download_pagination a.prev,#edd_download_pagination span.page-numbers.current,.fes-pagination span.page-numbers.current,.fes-product-list-pagination-container span.page-numbers.current{background-color:#ffffff;border-color:#ffffff;color:#28375a;}.footer-sidebar .widget-title, .footer-widget-title{border-color:#ffffff;border-bottom-width:0;}.blog-box.grid_dm{background:#ffffff;border-top-left-radius:3px;border-top-right-radius:3px;border-bottom-left-radius:3px;border-bottom-right-radius:3px;border-top-width:0px;border-right-width:0px;border-bottom-width:0px;border-left-width:0px;border-color:#cccccc;border-style:solid;}.blog-box.grid_dm .mayosis-fade-in img, .blog-box.grid_dm figure{border-top-left-radius:3px;border-top-right-radius:3px;border-bottom-left-radius:3px;border-bottom-right-radius:3px;}.blog-box.grid_dm .blog-meta{padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;}.theme--sidebar--widget,.subscribe-box-photo,.sidebar-theme{background:#e9edf7;}.theme--sidebar--widget,.subscribe-box-photo{border-top-left-radius:3px;border-top-right-radius:3px;border-bottom-left-radius:3px;border-bottom-right-radius:3px;}.theme--sidebar--widget .widget-title{border-top-left-radius:3px;border-top-right-radius:3px;border-bottom-left-radius:0px;border-bottom-right-radius:0px;margin-top:-10px;margin-right:-30px;margin-bottom:20px;margin-left:-30px;padding-top:25px;padding-right:25px;padding-bottom:25px;padding-left:25px;display:block;}.theme--sidebar--widget{padding-top:10px;padding-right:30px;padding-bottom:10px;padding-left:30px;}.product-search-form .download_cat_filter .mayosel-select span.current,.product-search-form .download_cat_filter .mayosel-select:after{color:#ffffff;}.product-search-form .download_cat_filter .mayosel-select:after{border-color:#ffffff;}.button,.media-style-d-favorite a.edd-wl-button, .media-style-d-favorite a.edd-wl-action.edd-wl-button,.btn,.ghost_button,.nl__item--submit,.back-to-top,.single-news-letter .nl__item--submit,#edd-purchase-button, .dm_register_button, .edd-submit, input.edd-submit[type=submit]{border-top-left-radius:3px;border-top-right-radius:3px;border-bottom-left-radius:3px;border-bottom-right-radius:3px;}.edd_star_rating span{color:#F3A712;}#fes-vendor-dashboard .acf-repeater .acf-row-handle.remove,#fes-vendor-dashboard .acf-repeater .acf-row-handle.order,#fes-vendor-dashboard .acf-file-uploader .file-icon,.acf-field input[type="text"], .acf-field input[type="password"], .acf-field input[type="date"], .acf-field input[type="datetime"], .acf-field input[type="datetime-local"], .acf-field input[type="email"], .acf-field input[type="month"], .acf-field input[type="number"], .acf-field input[type="search"], .acf-field input[type="tel"], .acf-field input[type="time"], .acf-field input[type="url"], .acf-field input[type="week"], .acf-field textarea, .acf-field select,input[type="text"], input[type="email"], input[type="password"], .solid-input input, textarea, #edd_profile_editor_form .mayosel-select, #edd_checkout_form_wrap .mayosel-select ,p.comment-form-comment textarea, #edd_login_form .edd-input, #edd_register_form .edd-input, #edd_checkout_form_wrap input.edd-input, #edd_checkout_form_wrap textarea.edd-input, #edd_checkout_form_wrap select.edd-select, #edd_profile_editor_form input:not([type="submit"]), #edd_profile_editor_form select, #contact textarea, .wpcf7-form-control-wrap textarea, .fes-pagination a.page-numbers, .fes-pagination span.page-numbers, .fes-fields input[type=text], .fes-fields input[type=email], .fes-fields input[type=password], .fes-fields textarea, .fes-fields input[type=url], .fes-vendor-comment-respond-form textarea, .fes-fields select, textarea#edd-reviews-reply, .vendor--search--box input[type="text"], .download_category .select2-container--default .select2-selection--single, .download_category .select2-container, .fes-fields .mayosel-select, #edd_checkout_form_wrap .mayosel-select .option:hover, #edd_checkout_form_wrap .mayosel-select .option.focus, #edd_profile_editor_form .mayosel-select .option:hover, #edd_profile_editor_form .mayosel-select .option.focus, #edd_profile_editor_form .mayosel-select, div.fes-form .fes-el .fes-fields input[type=text], div.fes-form .fes-el .fes-fields input[type=password], div.fes-form .fes-el .fes-fields input[type=email], div.fes-form .fes-el .fes-fields input[type=url], div.fes-form .fes-el .fes-fields input[type=number], div.fes-form .fes-el .fes-fields textarea,textarea#edd-reviews-review,.select2-container--default .select2-selection--multiple{background:#e9edf7;}#fes-vendor-dashboard .acf-table>thead>tr>th,#fes-vendor-dashboard .acf-table>tbody>tr>td,#fes-vendor-dashboard .acf-file-uploader .file-wrap,#fes-vendor-dashboard .acf-file-uploader .file-icon,.acf-field input[type="text"], .acf-field input[type="password"], .acf-field input[type="date"], .acf-field input[type="datetime"], .acf-field input[type="datetime-local"], .acf-field input[type="email"], .acf-field input[type="month"], .acf-field input[type="number"], .acf-field input[type="search"], .acf-field input[type="tel"], .acf-field input[type="time"], .acf-field input[type="url"], .acf-field input[type="week"], .acf-field textarea, .acf-field select,input[type="text"], input[type="email"], input[type="password"], .solid-input input, textarea, #edd_profile_editor_form .mayosel-select, #edd_checkout_form_wrap .mayosel-select ,p.comment-form-comment textarea, #edd_login_form .edd-input, #edd_register_form .edd-input, #edd_checkout_form_wrap input.edd-input, #edd_checkout_form_wrap textarea.edd-input, #edd_checkout_form_wrap select.edd-select, #edd_profile_editor_form input:not([type="submit"]), #edd_profile_editor_form select, #contact textarea, .wpcf7-form-control-wrap textarea, .fes-pagination a.page-numbers, .fes-pagination span.page-numbers, .fes-fields input[type=text], .fes-fields input[type=email], .fes-fields input[type=password], .fes-fields textarea, .fes-fields input[type=url], .fes-vendor-comment-respond-form textarea, .fes-fields select, textarea#edd-reviews-reply, .vendor--search--box input[type="text"], .download_category .select2-container--default .select2-selection--single, .download_category .select2-container, .fes-fields .mayosel-select, #edd_checkout_form_wrap .mayosel-select .option:hover, #edd_checkout_form_wrap .mayosel-select .option.focus, #edd_profile_editor_form .mayosel-select .option:hover, #edd_profile_editor_form .mayosel-select .option.focus, #edd_profile_editor_form .mayosel-select, div.fes-form .fes-el .fes-fields input[type=text], div.fes-form .fes-el .fes-fields input[type=password], div.fes-form .fes-el .fes-fields input[type=email], div.fes-form .fes-el .fes-fields input[type=url], div.fes-form .fes-el .fes-fields input[type=number], div.fes-form .fes-el .fes-fields textarea,textarea#edd-reviews-review,.select2-container--default .select2-selection--multiple{border-color:#e9edf7;}#fes-vendor-dashboard .acf-repeater .acf-row-handle.remove,#fes-vendor-dashboard .acf-repeater .acf-row-handle.order,.acf-field input[type="text"], .acf-field input[type="password"], .acf-field input[type="date"], .acf-field input[type="datetime"], .acf-field input[type="datetime-local"], .acf-field input[type="email"], .acf-field input[type="month"], .acf-field input[type="number"], .acf-field input[type="search"], .acf-field input[type="tel"], .acf-field input[type="time"], .acf-field input[type="url"], .acf-field input[type="week"], .acf-field textarea, .acf-field select,input[type="text"], input[type="email"], input[type="password"], .solid-input input, textarea, #edd_profile_editor_form .mayosel-select, #edd_checkout_form_wrap .mayosel-select ,p.comment-form-comment textarea, #edd_login_form .edd-input, #edd_register_form .edd-input, #edd_checkout_form_wrap input.edd-input, #edd_checkout_form_wrap textarea.edd-input, #edd_checkout_form_wrap select.edd-select, #edd_profile_editor_form input:not([type="submit"]), #edd_profile_editor_form select, #contact textarea, .wpcf7-form-control-wrap textarea, .fes-pagination a.page-numbers, .fes-pagination span.page-numbers, .fes-fields input[type=text], .fes-fields input[type=email], .fes-fields input[type=password], .fes-fields textarea, .fes-fields input[type=url], .fes-vendor-comment-respond-form textarea, .fes-fields select, textarea#edd-reviews-reply, .vendor--search--box input[type="text"], .download_category .select2-container--default .select2-selection--single, .download_category .select2-container, .fes-fields .mayosel-select, #edd_checkout_form_wrap .mayosel-select .option:hover, #edd_checkout_form_wrap .mayosel-select .option.focus, #edd_profile_editor_form .mayosel-select .option:hover, #edd_profile_editor_form .mayosel-select .option.focus, #edd_profile_editor_form .mayosel-select, div.fes-form .fes-el .fes-fields input[type=text], div.fes-form .fes-el .fes-fields input[type=password], div.fes-form .fes-el .fes-fields input[type=email], div.fes-form .fes-el .fes-fields input[type=url], div.fes-form .fes-el .fes-fields input[type=number], div.fes-form .fes-el .fes-fields textarea,textarea#edd-reviews-review,.select2-container--default .select2-selection--multiple{color:#28375a;}.acf-field input[type="text"], .acf-field input[type="password"], .acf-field input[type="date"], .acf-field input[type="datetime"], .acf-field input[type="datetime-local"], .acf-field input[type="email"], .acf-field input[type="month"], .acf-field input[type="number"], .acf-field input[type="search"], .acf-field input[type="tel"], .acf-field input[type="time"], .acf-field input[type="url"], .acf-field input[type="week"], .acf-field textarea, .acf-field select,p.comment-form-comment textarea, #edd_login_form .edd-input, #edd_register_form .edd-input, #edd_checkout_form_wrap input.edd-input, #edd_checkout_form_wrap textarea.edd-input, #edd_checkout_form_wrap select.edd-select, #edd_profile_editor_form input:not([type="submit"]), #edd_profile_editor_form select, #contact textarea, .wpcf7-form-control-wrap textarea, input[type="text"], input[type="email"], input[type="password"], .solid-input input,.fes-fields input[type=email], .fes-fields input[type=password], .fes-fields textarea, .fes-fields input[type=url], .fes-fields input[type=text], .fes-vendor-comment-respond-form textarea, .fes-fields select, textarea, .vendor--search--box input[type="text"], .download_category .select2-container--default .select2-selection--single, .fes-fields .mayosel-select, #edd_profile_editor_form .mayosel-select, div.fes-form .fes-el .fes-fields input[type=text], .download_category .select2-container, div.fes-form .fes-el .fes-fields input[type=password], div.fes-form .fes-el .fes-fields input[type=email], div.fes-form .fes-el .fes-fields input[type=url], div.fes-form .fes-el .fes-fields input[type=number], div.fes-form .fes-el .fes-fields textarea,.common-paginav a.next, .common-paginav a.prev, #edd_download_pagination a.next, #edd_download_pagination a.prev, .fes-pagination a.page-numbers, .fes-pagination span.page-numbers, .fes-product-list-pagination-container a.page-numbers, .fes-product-list-pagination-container span.page-numbers,.wpcf7-submit,textarea#edd-reviews-review,.select2-container--default .select2-selection--multiple{border-top-left-radius:3px;border-top-right-radius:3px;border-bottom-left-radius:3px;border-bottom-right-radius:3px;}#authormessage, #authormessagelogin, #mayosis_variable_price, #mayosis_vendorcontact, #mayosis_vendorlogin,.modal-content{background:#ffffff;}#authormessage, #authormessagelogin, #mayosis_variable_price, #mayosis_vendorcontact, #mayosis_vendorlogin,#mayosis_variable_price .edd_download_purchase_form .edd_price_options li, #mayosis_variable_price .edd_download_purchase_form .edd_price_options li label, #mayosis_variable_price h1,#mayosis_variable_price h2,#mayosis_variable_price h3, #mayosis_variable_price h4, #mayosis_vendorlogin h4, #mayosis_vendorlogin p,#mayosis_vendorlogin p a,#mayosis_vendorlogin p label, #mayosis_vendorlogin p label span,.modal, .modal p,.modal h1,.modal h2,.modal h3 ,.modal h4, .modal h5, .modal h6,.modal label{color:#28375a;}#authormessage, #authormessagelogin, #mayosis_variable_price, #mayosis_vendorcontact, #mayosis_vendorlogin, .modal-content{border-top-left-radius:3px;border-top-right-radius:3px;border-bottom-left-radius:3px;border-bottom-right-radius:3px;}.tag_breadcrumb_color .parchive-page-title{font-family:Lato;font-size:36px;font-weight:700;line-height:1.5;text-align:center;text-transform:none;color:#ffffff;}.promo_price, .promo_price span{color:#28375a;}.mayosis_list_product, .mayosis_list_product a,.mayosis_list_product .promo_price{color:#28375a;}.product-meta .product-title,.overlay-style .product-title,.product-meta .product-title a{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:1rem;font-weight:700;line-height:1.25;text-transform:none;}.default-product-template.product-main-header .single_main_header_products .edd-add-to-cart span{color:#ffffff;}.comment-button a.btn,.social-button{border-color:rgba(255,255,255,0.25);}.social-button a i{background-color:#ffffff;color:#000046;}.media-template-wrapper{background:#e9ebf7;}.photo-template-author{background:#fcfdff;margin-top:80px;margin-bottom:80px;}.prime-product-template h1.single-post-title{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:36px;font-weight:700;letter-spacing:-0.75px;line-height:45px;}.product-archive-breadcrumb .breadcrumb a,.product-archive-breadcrumb .breadcrumb,.product-archive-breadcrumb .breadcrumb .active{color:#ffffff;}.vendor--search--box input[type="text"]{-webkit-border-radius:20px;-moz-border-radius:20px;border-radius:20px;}.mayosis_wave-audio_template{padding-top:0;}.maysosis-audio_hero{padding-top:0px;padding-bottom:0px;padding-left:0px;padding-right:0px;}.mayosis-music-main-title{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:36px;font-weight:700;letter-spacing:-0.75px;line-height:45px;}.awp-player-thumb-wrapper{background:#222;}.single-post-block,.single-post-block p{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:1.125rem;font-weight:400;line-height:1.75;}.mayosis-global-breadcrumb-style h1.page_title_single, .mayosis-global-breadcrumb-style .breadcrumb a,.mayosis-global-breadcrumb-style .breadcrumb .active,.common-page-breadcrumb.page_breadcrumb .page_title_single,.common-page-breadcrumb.page_breadcrumb a,.common-page-breadcrumb.page_breadcrumb .breadcrumb .active{color:#ffffff;}.single-author--cover{background:#1e0050;}.single--author--content{background:#e9edf7;}.single--author--content, .single--author--content a, .single--author--content h1, .single--author--content h2, .single--author--content h3, .single--author--content h4, .single--author--content h5, .single--author--content h6, .single--author--content p{color:#28375a;}.author--box--btn .contact--au--btn a{background:rgb(31 0 70 / 0%);border-color:#28375a;color:#28375a;}.author--box--btn .contact--au--btn a:hover{background:#28375a;border-color:#28375a;color:#ffffff;}.follow--au--btn a{background:rgb(31 0 70 / 0%);border-color:#28375a;color:#28375a;}.follow--au--btn a:hover{background:#28375a;border-color:#28375a;color:#ffffff;}body,table tbody tr td,table thead tr th, table tfoot tr td,.edd-download .single-post-block,.edd-download .single-post-block p{font-size:16px;line-height:30px;}h1.page_title_single{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:2.25rem;font-weight:700;line-height:1.25;}h1.single-post-title{font-size:36px;line-height:45px;}h1{font-size:36px;letter-spacing:-0.75px;line-height:45px;}h2{font-size:30px;letter-spacing:-0.5px;line-height:42px;}h3{font-size:24px;line-height:36px;}h4{font-size:19px;line-height:30px;}h5{font-size:16px;line-height:24px;}h6{font-size:14px;letter-spacing:0.5px;line-height:24px;}#mayosis-menu.msv-main-menu > ul > li > a,.main-header ul li.cart-style-one a.cart-button,.search-dropdown-main a,.menu-item a,.cart-style-two .cart-button{font-family:Lato;font-size:16px;font-weight:400;}#mayosis-menu.msv-main-menu ul ul a, .nav-style-megamenu>li.nav-item .dropdown-menu .dropdown-item{font-family:Lato;font-size:16px;font-weight:400;line-height:30px;}#top-main-menu > ul > li > a ,.top-header #cart-menu li a{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:0.875rem;font-weight:400;line-height:0.875rem;}#top-main-menu ul ul a{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:0.875rem;font-weight:400;line-height:1;}#mayosis-menu.mayosis-bottom-menu > ul > li > a{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:1rem;font-weight:400;}#mayosis-menu.mayosis-bottom-menu ul ul a{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:1rem;font-weight:400;line-height:1.75;}#sidebar-wrapper .navbar-nav > li > a, #sidebar-wrapper #mega-menu-wrap-main-menu #mega-menu-main-menu > li.mega-menu-item > a.mega-menu-link{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:0.875rem;font-weight:400;line-height:1.5;}#sidebar-wrapper .dropdown-menu > li > a{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:0.875rem;font-weight:400;line-height:1.5;}.mayosis-standard-bar{background:#483dba;background-color:#483dba;background-repeat:repeat;background-position:center center;background-attachment:scroll;-webkit-background-size:cover;-moz-background-size:cover;-ms-background-size:cover;-o-background-size:cover;background-size:cover;}.mayosis-sticky-bar-btn{background:#f6d937;font-family:Roboto;font-size:16px;font-weight:400;line-height:1.5;text-transform:none;color:#28375a;padding-top:6px;padding-bottom:6px;padding-left:12px;padding-right:12px;border-top-left-radius:3px;border-top-right-radius:3px;border-bottom-left-radius:3px;border-bottom-right-radius:3px;}#mayosis-sticky-bar,.mayosis-sticky-text{font-family:Roboto;font-size:16px;font-weight:400;line-height:1.5;text-align:center;text-transform:none;color:#ffffff;}.howdydo-box{padding-top:10px;padding-bottom:10px;padding-left:0px;padding-right:0px;}.mayosis-sticky-notification-timer .countdown .emerce-count-value{background:#ffffff;color:#222;}.mayosis-sticky-notification-timer .countdown .separator{color:#fff;}.mayosis-sticky-cart-standard#mayosis-sticky-cart-bar{background:#ffffff;background-color:#ffffff;background-repeat:repeat;background-position:center center;background-attachment:scroll;-webkit-background-size:cover;-moz-background-size:cover;-ms-background-size:cover;-o-background-size:cover;background-size:cover;}#mayosis-sticky-cart-bar h4{color:#222;}#mayosis-sticky-cart-bar .global-price-msc{color:#222;}#mayosis-sticky-cart-bar .multiple_button_v, #mayosis-sticky-cart-bar .edd-submit{background:#222;border-color:#222;color:#fff;}/* latin-ext */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://solverwp.com/wp-content/fonts/lato/S6uyw4BMUTPHjxAwWCWtFCfQ7A.woff) format('woff');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://solverwp.com/wp-content/fonts/lato/S6uyw4BMUTPHjx4wWCWtFCc.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://solverwp.com/wp-content/fonts/lato/S6u9w4BMUTPHh6UVSwaPHw3q5d0N7w.woff) format('woff');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://solverwp.com/wp-content/fonts/lato/S6u9w4BMUTPHh6UVSwiPHw3q5d0.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://solverwp.com/wp-content/fonts/roboto/KFOmCnqEu92Fr1Mu72xMKTU1Kvnz.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://solverwp.com/wp-content/fonts/roboto/KFOmCnqEu92Fr1Mu5mxMKTU1Kvnz.woff) format('woff');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://solverwp.com/wp-content/fonts/roboto/KFOmCnqEu92Fr1Mu7mxMKTU1Kvnz.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://solverwp.com/wp-content/fonts/roboto/KFOmCnqEu92Fr1Mu4WxMKTU1Kvnz.woff) format('woff');
  unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://solverwp.com/wp-content/fonts/roboto/KFOmCnqEu92Fr1Mu7WxMKTU1Kvnz.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://solverwp.com/wp-content/fonts/roboto/KFOmCnqEu92Fr1Mu7GxMKTU1Kvnz.woff) format('woff');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://solverwp.com/wp-content/fonts/roboto/KFOmCnqEu92Fr1Mu4mxMKTU1Kg.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}</style></head>

<!-- Begin Main Layout --> 
<body class="error404 wp-embed-responsive elementor-default elementor-kit-11">
    
       
        
    
    <div class="mayosis-wrapper">

          <header id="main-header" class="main-header header-stacked mayosis-header-sticky-mainheader  ">
      	
<div class="header-master stickydisabled smartenble">
            <div class="container">
         
            <div class="d-none d-lg-block">
            <div class="to-flex-row  th-flex-flex-middle">
            
            <!-- Start Desktop Content -->
            <div class="to-flex-col th-col-left  default-logo-box  flexleft">
                

                <div class="site-logo sticky-enabled">
        
              <a href="https://solverwp.com/" class="logo_box">
                  
                  <img src="https://solverwp.com/wp-content/uploads/2020/10/sw.png" class="img-responsive main-logo d-none d-lg-block" alt="" style="width:;"  />
                  
                                    <img src="https://solverwp.com/wp-content/uploads/2020/10/sw.png" class="img-responsive main-logo d-block d-lg-none" alt="" style="width:;"  />
                  												<img src="https://teconce.com/mayosis-maindemo/wp-content/uploads/sites/4/2019/01/logo.png" class="img-responsive sticky-logo" alt=""  style="width:;"  />
						 						 
						 </a>
						 
</div>

            </div>




            <div class="to-flex-col th-col-center  flexleft">

                <div class="main-navigation text-right">                     
<div id="mayosis-menu" class="msv-main-menu"><ul id="menu-main-menu" class="menu"><li id="menu-item-3336" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://solverwp.com/wordpress-items/">   <span class="menu-item-text">WordPress</span></a></li>
<li id="menu-item-3335" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://solverwp.com/html-template-marketplace/">   <span class="menu-item-text">HTML</span></a></li>
<li id="menu-item-3334" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://solverwp.com/react-template/">   <span class="menu-item-text">React</span></a></li>
<li id="menu-item-3333" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://solverwp.com/psd-items/">   <span class="menu-item-text">PSD</span></a></li>
<li id="menu-item-3351" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://solverwp.com/contact/">   <span class="menu-item-text">Contact</span></a></li>
</ul></div></div>
            </div>


            <div class="to-flex-col th-col-right  flexright">

                

	
	
	<ul id="cart-menu" class="mayosis-option-menu d-none d-lg-block">
                        					
					<li class="dropdown cart_widget cart-style-one"><a href="#" data-toggle="dropdown" class="cart-button"><i class="zil zi-cart"></i> <span class="items edd-cart-quantity">0</span></a><ul role="menu" class="dropdown-menu mini_cart"><li class="widget"><div class="widget widget_edd_cart_widget"><p class="edd-cart-number-of-items" style="display:none;">Number of items in cart: <span class="edd-cart-quantity">0</span></p>
<ul class="edd-cart">

	<li class="cart_item empty"><span class="edd_empty_cart">Your cart is empty.</span></li>
<li class="cart_item edd-cart-meta edd_total" style="display:none;">Total: <span class="cart-total">&#36;0.00</span></li>
<li class="cart_item edd_checkout" style="display:none;"><a href="https://solverwp.com/checkout/">Checkout</a></li>

</ul>
</div> 
					</li></ul></li> 
					
				
		</ul>
		
		<ul class="mobile-cart d-block d-lg-none">
		<li class="cart-style-one"><a href="https://solverwp.com/checkout/" class="btn btn-danger btn-lg mobile-cart-button">
                        <i class="zil zi-cart"></i></a></li>
                        
        </ul>
                        	
<ul id="search-menu" class="mayosis-option-menu">


	<li class="dropdown search-dropdown-main">
            <a href="#" class="" data-bs-toggle="dropdown"  aria-expanded="false" id="dropdownMenuLink"><i class="zil zi-search" aria-hidden="true"></i></a>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                <li>
                <form role="search" method="get" class="search-form-none search-form-collapsed" action="https://solverwp.com/">
						                    <input  value="" placeholder="Type and Hit Enter" type="search" name="s" id="s" class="dm_search"   >
                        <button type="submit" value="Search">
                            <i class="zil zi-search" aria-hidden="true"></i>
                            				<input type="hidden" name="post_type" value="download">
				                        </button>  
                        
                </form>
                </li>
              </ul>
          </li>
          
          

</ul><ul id="account-button" class="mayosis-option-menu d-none d-lg-block">
    
<li class="menu-item">
            
                <a href="https://solverwp.com/login/" class="login-button" ><i class="zil zi-user"></i> Login</a>
            </li>

</ul>

<div id="account-mob" class="mayosis-option-menu d-block d-lg-none">
     
		<div id="mayosis-sidemenu">
		       
		  <ul>
               <li class="menu-item msv-mob-login-menu">
                <a href="https://solverwp.com/login/" ><i class="zil zi-user"></i> Login</a>
            </li>
        </ul>
</div>
   
</div>

<div id="mayosis_vendorlogin" class="lity-hide">
              
                  <div class="modal-body">
                       <h4 class="modal-title mb-4">Login</h4>
                       	<div class="row main_login_form">
	<div class="login_form_dm">
	<form id="edd_login_form" class="edd_form" action="" method="post">
		<fieldset>
						<p class="edd-login-username">
				
				<input name="edd_user_login" id="edd_user_login" class="edd-required edd-input" type="text" placeholder="Your Username or Email"/>
			</p>
			<p class="edd-login-password">
				
				<input name="edd_user_pass" id="edd_user_pass" class="edd-password edd-required edd-input" type="password" placeholder="Your Password"/>
			</p>
			<p class="edd-login-remember">
				<label><input name="rememberme" type="checkbox" id="rememberme" value="forever" /> <span> Remember Me</span></label>
			</p>
			<p class="edd-lost-password">
				<a href="https://solverwp.com/wp-login.php?action=lostpassword">
					Lost Password?				</a>
			</p>
			<p class="edd-login-submit">
				<input type="hidden" name="edd_redirect" value="https://solverwp.com/checkout/purchase-history/"/>
				<input type="hidden" name="edd_login_nonce" value="df671352e0"/>
				<input type="hidden" name="edd_action" value="user_login"/>
				<input id="edd_login_submit" type="submit" class="edd_submit edd-submit" value="Login"/>
			</p>
			
					</fieldset>
	</form>
		</div>
	
	</div>
                      <a class="sigining-up text-center" href="">New here? Create an account!</a>
                  </div>
</div>
            </div>
        </div>
    </div>
    <!-- End Desktop Content -->

    <!-- Start Mobile Content -->
    <div class="d-block d-lg-none">
                    <div class="to-flex-row  th-flex-flex-middle">
                                <div class="to-flex-col th-col-left">

                    

                <div class="site-logo sticky-enabled">
        
              <a href="https://solverwp.com/" class="logo_box">
                  
                  <img src="https://solverwp.com/wp-content/uploads/2020/10/sw.png" class="img-responsive main-logo d-none d-lg-block" alt="" style="width:;"  />
                  
                                    <img src="https://solverwp.com/wp-content/uploads/2020/10/sw.png" class="img-responsive main-logo d-block d-lg-none" alt="" style="width:;"  />
                  												<img src="https://teconce.com/mayosis-maindemo/wp-content/uploads/sites/4/2019/01/logo.png" class="img-responsive sticky-logo" alt=""  style="width:;"  />
						 						 
						 </a>
						 
</div>


                </div>

                <div class="to-flex-col th-col-center ">

                    
                </div>


                <div class="to-flex-col th-col-right  flexright">

                    

	
	
	<ul id="cart-menu" class="mayosis-option-menu d-none d-lg-block">
                        					
					<li class="dropdown cart_widget cart-style-one"><a href="#" data-toggle="dropdown" class="cart-button"><i class="zil zi-cart"></i> <span class="items edd-cart-quantity">0</span></a><ul role="menu" class="dropdown-menu mini_cart"><li class="widget"><div class="widget widget_edd_cart_widget"><p class="edd-cart-number-of-items" style="display:none;">Number of items in cart: <span class="edd-cart-quantity">0</span></p>
<ul class="edd-cart">

	<li class="cart_item empty"><span class="edd_empty_cart">Your cart is empty.</span></li>
<li class="cart_item edd-cart-meta edd_total" style="display:none;">Total: <span class="cart-total">&#36;0.00</span></li>
<li class="cart_item edd_checkout" style="display:none;"><a href="https://solverwp.com/checkout/">Checkout</a></li>

</ul>
</div> 
					</li></ul></li> 
					
				
		</ul>
		
		<ul class="mobile-cart d-block d-lg-none">
		<li class="cart-style-one"><a href="https://solverwp.com/checkout/" class="btn btn-danger btn-lg mobile-cart-button">
                        <i class="zil zi-cart"></i></a></li>
                        
        </ul>
                        	 <div  class="mobile--nav-menu">
       <div class="top-part-mobile to-flex-row">
            <div class="to-flex-col th-col-left">
                            </div>
            
            <div class="to-flex-col th-col-right">
                            </div>
        </div>
        
        <div class="mobile-menu-main-part">
            <div class="col-sm-12 col-12">
                  <div id="mayosis-sidemenu" class="menu-main-menu-container"><ul id="menu-main-menu-1" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://solverwp.com/wordpress-items/">  <span class="menu-item-class">WordPress</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://solverwp.com/html-template-marketplace/">  <span class="menu-item-class">HTML</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://solverwp.com/react-template/">  <span class="menu-item-class">React</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://solverwp.com/psd-items/">  <span class="menu-item-class">PSD</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://solverwp.com/contact/">  <span class="menu-item-class">Contact</span></a></li>
</ul></div>            </div>
        </div>
       
       
        <div class="bottom-part-mobile to-flex-row">
            <div class="to-flex-col th-col-left">
                                            </div>
            
            <div class="to-flex-col th-col-right">
                            </div>
        </div>
    </div>
    <div class="overlaymobile"></div>
     <ul  class="mobile-nav">
     <li class="burger"><span></span></li>
     </ul>
                </div>

            </div>
        </div>

        <!-- End Mobile Content -->
            
    </div>
</div><!-- .header-master -->

</header>

	<div class="row common-page-breadcrumb page_breadcrumb">
	    	<div class="container">
	    <div class="col-md-12 col-12">
	<h2 class="page_title_single">Sorry!! Something Went Wrong!!!</h2>
						</div>
		</div>
		</div>
<section class="fourzerofour-area">
		<div class="container">
			<h1>40 + 4 = <span>404</span></h1>
			<h3>
				The Page You Are Looking For is Missing, Misspelled or Doesn&#039;t Exist!</h3>
			
		</div>
		<div class="fourzerofour-info container-fluid">
		    	<div class="container">
				<p>We are Sorry For This Inconvenience! Don&#039;t Worry!! <br>
					Our <a href="https://solverwp.com/"> Homepage</a> will Guide You Through All of Our Awesome Things, Or You Can Have A Quick Look at Our Products!!!</p>
			</div>
			</div>
	</section>

	<div class="clearfix"></div>
	
		
	  

    <footer class="main-footer container-fluid">
        <div class="container">
            <div class="footer-row">

                <!-- Begin Footer Section-->
	
		
	
		
	
		<div class="footer-widget mx-one" >
        						<div class="footer-sidebar widget_digital_about">	<div class="sidebar-theme">	
 <img src="https://solverwp.com/wp-content/uploads/2020/10/sw.png" alt="Footer Logo" class="img-responsive footer-logo"/>
						<p class="footer-text">We are Professional Web Development team. We are create Professional psd template with eye caching design and we convert psd to html template, psd to WordPress theme and plugin, psd to custom website, and psd to laravel template. Mail us: <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="daa9b5b6acbfa8adaae8eb9abdb7bbb3b6f4b9b5b7">[email&#160;protected]</a></p>
		
                   
                   
<div class="clearfix"></div>
</div>

	</div>				    </div>
    <div class="footer-widget mx-two" >
        					<div class="footer-sidebar widget_edd_categories_tags_widget"><h4 class="footer-widget-title">Products</h4><ul class="edd-taxonomy-widget">
	<li class="cat-item cat-item-281"><a href="https://solverwp.com/downloads/category/envato/">Envato</a> (1)
</li>
	<li class="cat-item cat-item-280"><a href="https://solverwp.com/downloads/category/exclusive/">EXCLUSIVE</a> (5)
</li>
	<li class="cat-item cat-item-262"><a href="https://solverwp.com/downloads/category/free/">Free</a> (2)
</li>
	<li class="cat-item cat-item-244"><a href="https://solverwp.com/downloads/category/html-template/">HTML</a> (4)
</li>
	<li class="cat-item cat-item-269"><a href="https://solverwp.com/downloads/category/pro/">Pro</a> (12)
</li>
	<li class="cat-item cat-item-288"><a href="https://solverwp.com/downloads/category/pro-theme/">Pro Theme</a> (1)
</li>
	<li class="cat-item cat-item-245"><a href="https://solverwp.com/downloads/category/psd/">PSD</a> (3)
</li>
	<li class="cat-item cat-item-246"><a href="https://solverwp.com/downloads/category/react-template/">React</a> (4)
</li>
	<li class="cat-item cat-item-259"><a href="https://solverwp.com/downloads/category/wordpress/">WordPress</a> (8)
<ul class='children'>
	<li class="cat-item cat-item-260"><a href="https://solverwp.com/downloads/category/wordpress/plugins/">Plugins</a> (5)
</li>
	<li class="cat-item cat-item-261"><a href="https://solverwp.com/downloads/category/wordpress/themes/">Themes</a> (3)
</li>
	<li class="cat-item cat-item-289"><a href="https://solverwp.com/downloads/category/wordpress/wordpress-pro/">WordPress Pro</a> (5)
</li>
</ul>
</li>
</ul>
</div>				    </div>
	<div class="footer-widget mx-three" >
        					<div class="widget_text footer-sidebar widget_custom_html"><h4 class="footer-widget-title">License</h4><div class="textwidget custom-html-widget">You can use all our themes/plugins for personal and commercial use. All theme/plugins under 100% GPL license</div></div><div class="footer-sidebar widget_nav_menu"><div class="menu-checkout-container"><ul id="menu-checkout" class="menu"><li id="menu-item-3960" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3960"><a href="https://solverwp.com/privacy-policy/">Privacy Policy</a></li>
<li id="menu-item-3961" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3961"><a href="https://solverwp.com/terms-and-condition/">Terms and Condition</a></li>
</ul></div></div>				    </div>
    
    <div class="footer-widget mx-four" >
         					<div class="footer-sidebar widget_mayosis_social_widget">  <div class="sidebar-theme">
      		<h4 class="footer-widget-title">Find Us ON</h4>
		            						<div class="without-bg-social" style="text-align:left">
                   							<a href="https://web.facebook.com/SolverWp" class="facebook" target="_self"><i class="zil zi-facebook"></i></a>
														
							 							<a href="https://twitter.com/SolverWp" class="twitter" target="_self"><i class="zil zi-twitter"></i></a>
														
							
														<a href="https://www.pinterest.com/solverwp/_created/" class="pinterest" target="_self"><i class="zil zi-pinterest"></i></a>
														
														
										            	
			            					            <a href="https://www.youtube.com/channel/UChY2KzV8q-R_AHWXC4Ige2Q?view_as=subscriber" class="youtube" target="_self"><i class="zil zi-youtube"></i></a>
				            				            
				            				            
				            				            
				            				            
				             				            <a href="https://themeforest.net/user/solverwp/portfolio" class="envato" target="_self"><i class="zil zi-envato"></i></a>
				            				            
				             				            
				             				            
				             						</div>
			<div class="clearfix"></div>
</div>
	</div><div class="footer-sidebar dm_subscribe_widget">		<div class="sidebar-theme">
		<div class="single-product-widget">
			<h4 class="widget-title"><i class="zil zi-envelope" aria-hidden="true"></i> Subscribe </h4>
			<div class="details-table_subscribe">
				<div role="form" class="wpcf7" id="wpcf7-f82-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/demo/html/nextpage/popper.js#wpcf7-f82-o1" method="post" class="wpcf7-form init" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="82" />
<input type="hidden" name="_wpcf7_version" value="5.4" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f82-o1" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
</div>
<div class="single-news-letter">
<span class="wpcf7-form-control-wrap email"><input type="email" name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email nl__item" aria-required="true" aria-invalid="false" placeholder="Your Email Address" /></span><br />
<button type="submit" class="nl__item--submit"><i class="zil zi-arrow-right"></i></button>
</div>
<p style="display: none !important;"><label>&#916;<textarea name="_wpcf7_ak_hp_textarea" cols="45" rows="8" maxlength="100"></textarea></label><input type="hidden" id="ak_js_1" name="_wpcf7_ak_js" value="242"/><script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.getElementById( "ak_js_1" ).setAttribute( "value", ( new Date() ).getTime() );</script></p><div class="wpcf7-response-output" aria-hidden="true"></div></form></div>			</div>
	</div>
	</div>
		</div>				    </div>
    
		
	
		
	
		
		
	
	
            </div>
                    </div>
    </footer>



    <div class="copyright-footer container-fluid">
        <div class="container">

                            <div class="text-center copyright-full-width-text">
                                                                    Copyright 2024
by solverwp                                    </div>
            
        </div>
    </div>
<!-- End Footer Section-->		



</div>
</div>
		<a id="back-to-top" href="#" class="back-to-top" role="button"><i class="zil zi-chevron-up"></i></a>
	
   <script type="text/javascript" src="https://c0.wp.com/c/6.4.5/wp-includes/js/dist/vendor/wp-polyfill-inert.min.js" id="wp-polyfill-inert-js"></script>
<script type="text/javascript" src="https://c0.wp.com/c/6.4.5/wp-includes/js/dist/vendor/regenerator-runtime.min.js" id="regenerator-runtime-js"></script>
<script type="text/javascript" src="https://c0.wp.com/c/6.4.5/wp-includes/js/dist/vendor/wp-polyfill.min.js" id="wp-polyfill-js"></script>
<script type="text/javascript" src="https://c0.wp.com/c/6.4.5/wp-includes/js/dist/hooks.min.js" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://c0.wp.com/c/6.4.5/wp-includes/js/dist/i18n.min.js" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
/* ]]> */
</script>
<script type="text/javascript" src="https://c0.wp.com/c/6.4.5/wp-includes/js/dist/url.min.js" id="wp-url-js"></script>
<script type="text/javascript" src="https://c0.wp.com/c/6.4.5/wp-includes/js/dist/api-fetch.min.js" id="wp-api-fetch-js"></script>
<script type="text/javascript" id="wp-api-fetch-js-after">
/* <![CDATA[ */
wp.apiFetch.use( wp.apiFetch.createRootURLMiddleware( "https://solverwp.com/wp-json/" ) );
wp.apiFetch.nonceMiddleware = wp.apiFetch.createNonceMiddleware( "ffab9311a0" );
wp.apiFetch.use( wp.apiFetch.nonceMiddleware );
wp.apiFetch.use( wp.apiFetch.mediaUploadMiddleware );
wp.apiFetch.nonceEndpoint = "https://solverwp.com/wp-admin/admin-ajax.php?action=rest-nonce";
/* ]]> */
</script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"cached":"1"};
/* ]]> */
</script>
<script type="text/javascript" src="https://solverwp.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.4" id="contact-form-7-js"></script>
<script type="text/javascript" id="edd-ajax-js-extra">
/* <![CDATA[ */
var edd_scripts = {"ajaxurl":"https:\/\/solverwp.com\/wp-admin\/admin-ajax.php","position_in_cart":"-1","has_purchase_links":"","already_in_cart_message":"You have already added this item to your cart","empty_cart_message":"Your cart is empty","loading":"Loading","select_option":"Please select an option","is_checkout":"0","default_gateway":"","redirect_to_checkout":"0","checkout_page":"https:\/\/solverwp.com\/checkout\/","permalinks":"1","quantities_enabled":"","taxes_enabled":"0"};
/* ]]> */
</script>
<script type="text/javascript" src="https://solverwp.com/wp-content/plugins/easy-digital-downloads/assets/js/edd-ajax.min.js?ver=2.11.5" id="edd-ajax-js"></script>
<script type="text/javascript" id="em-puchase-code-validator-js-extra">
/* <![CDATA[ */
var js_response = {"authToken":"jGy0Di2Kwm6JOxx0Z18F5oeohRYvLqlo","responseOne":"Your purchase code is valid & result is listed above!","responseTwo":"Your purchase code is not valid or having problem with connecting with the market api. Please check again!","responseThree":"Invalid Code!","responseFour":"Please go to the settings page & set your token to see validator working!"};
/* ]]> */
</script>
<script type="text/javascript" src="https://solverwp.com/wp-content/plugins/em-purchase-code-validator/public/assets/js/em-puchase-code-validator-public.js?ver=1.1" id="em-puchase-code-validator-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/plugins/mayosis-core/public/elementor/assets/js/mayo-elementor.js?ver=1.1" id="before-after-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/themes/mayosis/js/smoothscroll.min.js?ver=1.1" id="smoothscroll-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/themes/mayosis/js/bootstrap.min.js?ver=5.0" id="mayosis-bootstarap-js"></script>
<script type="text/javascript" src="https://c0.wp.com/c/6.4.5/wp-includes/js/hoverIntent.min.js" id="hoverIntent-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/themes/mayosis/js/youtube.js?ver=1.0" id="mayosis-yoututbe-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/themes/mayosis/js/theme.min.js?ver=1.0" id="mayosis-theme-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/themes/mayosis/js/jquery.common.min.js?ver=1.5.6" id="mayosis-common-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/themes/mayosis/js/sticky.js?ver=1.0" id="mayosis-smart-sticky-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/themes/mayosis/js/sticky-sidebar-min.js?ver=1.0" id="mayosis-sticky-social-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/themes/mayosis/js/mayosisloadmore.js?ver=1.0" id="mayosis-load-more-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/themes/mayosis/js/plyr.min.js?ver=3.6.8" id="plyr-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/themes/mayosis/js/jquery.parallax-scroll.js?ver=1.1" id="mayosis-parallax-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/themes/mayosis/js/parallax.hover.js?ver=1.5" id="mayosis-object-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/themes/mayosis/js/gallery.main.js?ver=0.9.4" id="mayosis-product-gallery-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/themes/mayosis/js/jquery.beerslider.js?ver=1.1" id="beerslider-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/themes/mayosis/js/swiper.min.js?ver=1.1" id="swiperjs-js"></script>
<script type="text/javascript" src="https://solverwp.com/wp-content/plugins/jetpack/jetpack_vendor/automattic/jetpack-lazy-images/dist/intersection-observer.js?minify=false&amp;ver=f5a9d453c5a79e347f9ee90353c1abdf" id="jetpack-lazy-images-polyfill-intersectionobserver-js"></script>
<script type="text/javascript" id="jetpack-lazy-images-js-extra">
/* <![CDATA[ */
var jetpackLazyImagesL10n = {"loading_warning":"Images are still loading. Please cancel your print and try again."};
/* ]]> */
</script>
<script type="text/javascript" src="https://solverwp.com/wp-content/plugins/jetpack/jetpack_vendor/automattic/jetpack-lazy-images/dist/lazy-images.js?minify=false&amp;ver=25eafb3f2ad93939cdfaaa7782cb8b85" id="jetpack-lazy-images-js"></script>
<script src='https://stats.wp.com/e-202437.js' defer></script>
<script>
	_stq = window._stq || [];
	_stq.push([ 'view', {v:'ext',j:'1:10.9.2',blog:'185303193',post:'0',tz:'0',srv:'solverwp.com'} ]);
	_stq.push([ 'clickTrackerInit', '185303193', '0' ]);
</script>
</body>
<!-- End Main Layout --> 

</html>

<!-- Page cached by LiteSpeed Cache 5.7.0.1 on 2024-09-12 13:22:24 -->